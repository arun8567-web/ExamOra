package com.examora.app.notify

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.examora.app.MainActivity
import com.examora.app.R

class ExamNotificationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val name = inputData.getString("name") ?: return Result.success()
        val id = inputData.getLong("id", 0L)
        val kind = inputData.getString("kind") ?: ExamNotifier.KIND_NOW
        val isEvent = inputData.getBoolean("event", false)

        val ctx = applicationContext
        ExamNotifier.createChannel(ctx)

        val isNow = kind == ExamNotifier.KIND_NOW
        val title = if (isEvent) "Event reminder" else "Exam reminder"
        val text = if (isNow) {
            "$name ka time ho gaya. All the best!"
        } else {
            "$name kal hai. Aaj revision karo aur neend poori lo."
        }

        val openApp = PendingIntent.getActivity(
            ctx,
            0,
            Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(ctx, ExamNotifier.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_examora)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()

        try {
            val manager = NotificationManagerCompat.from(ctx)
            if (manager.areNotificationsEnabled()) {
                manager.notify((id * 2 + if (isNow) 1 else 0).toInt(), notification)
            }
        } catch (e: SecurityException) {
            // Notification permission not granted; nothing to show.
        }
        return Result.success()
    }
}
