package com.examora.app.ui.planner

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.data.planner.ChapterEntity
import com.examora.app.data.planner.StudySessionEntity
import com.examora.app.data.planner.SubjectEntity
import com.examora.app.ui.PlannerViewModel
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamGreen
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamSurfaceHigh
import com.examora.app.ui.theme.ExamTextSoft
import com.examora.app.util.formatDay
import com.examora.app.util.formatDuration
import com.examora.app.util.formatTime
import com.examora.app.util.mondayOf
import com.examora.app.util.startMillis
import com.examora.app.util.todayDate
import com.examora.app.util.toLocalDate
import java.time.LocalDate

@Composable
fun SessionRow(
    session: StudySessionEntity,
    subject: SubjectEntity?,
    chapter: ChapterEntity?,
    onToggle: () -> Unit,
    onEdit: () -> Unit,
    onTomorrow: () -> Unit,
    onDelete: () -> Unit
) {
    val accent = if (subject != null) subjectColor(subject.colorIndex) else ExamTextSoft
    val details = listOfNotNull(subject?.name, chapter?.name).joinToString(" - ")
    val heading = session.title.ifBlank { details.ifBlank { "Study session" } }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ExamSurface)
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(
                checked = session.done,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(checkedColor = ExamOrange)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    heading,
                    fontWeight = FontWeight.SemiBold,
                    textDecoration = if (session.done) TextDecoration.LineThrough else null
                )
                if (session.title.isNotBlank() && details.isNotBlank()) {
                    Text(details, color = accent, fontSize = 12.sp)
                }
                Text(
                    formatDay(session.startMillis) + "  " + formatTime(session.startMillis) +
                        " - " + formatTime(session.endMillis) +
                        " (" + formatDuration(session.minutes) + ")",
                    color = ExamTextSoft,
                    fontSize = 12.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        priorityLabel(session.priority),
                        color = priorityColor(session.priority),
                        fontSize = 12.sp
                    )
                    Text(
                        if (session.done) "Done" else "Pending",
                        color = if (session.done) ExamGreen else ExamTextSoft,
                        fontSize = 12.sp
                    )
                }
            }
            IconButton(onClick = onEdit) {
                Icon(Icons.Filled.Edit, contentDescription = "Edit / reschedule")
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete")
            }
        }
        if (!session.done) {
            TextButton(onClick = onTomorrow) {
                Text("Kal par shift karo", color = ExamOrange, fontSize = 12.sp)
            }
        }
    }
}

private fun dayLabel(date: LocalDate, today: LocalDate): String = when (date) {
    today -> "Aaj  -  " + formatDay(date.startMillis())
    today.plusDays(1) -> "Kal  -  " + formatDay(date.startMillis())
    else -> formatDay(date.startMillis())
}

@Composable
fun SessionsTab(vm: PlannerViewModel) {
    val sessions by vm.sessions.collectAsState()
    val subjects by vm.subjects.collectAsState()
    val chapters by vm.chapters.collectAsState()
    val goal by vm.dailyGoalMinutes.collectAsState()

    var viewMode by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<StudySessionEntity?>(null) }
    var deleting by remember { mutableStateOf<StudySessionEntity?>(null) }
    var goalDialog by remember { mutableStateOf(false) }

    val subjectMap = remember(subjects) { subjects.associateBy { it.id } }
    val chapterMap = remember(chapters) { chapters.associateBy { it.id } }

    val today = todayDate()
    val weekStart = mondayOf(today)
    val weekEnd = weekStart.plusDays(7)

    val shown = sessions.filter { session ->
        val d = session.startMillis.toLocalDate()
        when (viewMode) {
            0 -> d == today
            1 -> !d.isBefore(weekStart) && d.isBefore(weekEnd)
            else -> true
        }
    }
    val groups = shown
        .groupBy { it.startMillis.toLocalDate() }
        .entries
        .sortedBy { it.key.toEpochDay() }

    val todaySessions = sessions.filter { it.startMillis.toLocalDate() == today }
    val plannedMin = todaySessions.sumOf { it.minutes }
    val doneMin = todaySessions.filter { it.done }.sumOf { it.minutes }
    val fraction = if (goal <= 0) 0f else (doneMin.toFloat() / goal).coerceIn(0f, 1f)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, top = 12.dp, end = 20.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(ExamSurface)
                    .padding(16.dp)
            ) {
                Text("Aaj ka study goal", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    formatDuration(doneMin) + " done / " + formatDuration(goal) +
                        " goal   (planned: " + formatDuration(plannedMin) + ")",
                    color = ExamTextSoft,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = ExamOrange,
                    trackColor = ExamSurfaceHigh
                )
                TextButton(onClick = { goalDialog = true }) {
                    Text("Goal badlo", color = ExamOrange)
                }
            }
        }
        item {
            Button(
                onClick = { adding = true },
                colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
            ) { Text("Session add karo") }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = viewMode == 0, onClick = { viewMode = 0 }, label = { Text("Aaj") })
                FilterChip(selected = viewMode == 1, onClick = { viewMode = 1 }, label = { Text("Is hafte") })
                FilterChip(selected = viewMode == 2, onClick = { viewMode = 2 }, label = { Text("Sab") })
            }
        }
        if (groups.isEmpty()) {
            item {
                Text(
                    "Is filter me koi session nahi hai. Upar se add karo.",
                    color = ExamTextSoft
                )
            }
        }
        groups.forEach { entry ->
            item { SectionHeader(dayLabel(entry.key, today)) }
            items(entry.value.sortedBy { it.startMillis }) { session ->
                SessionRow(
                    session = session,
                    subject = subjectMap[session.subjectId],
                    chapter = chapterMap[session.chapterId],
                    onToggle = { vm.toggleSession(session) },
                    onEdit = { editing = session },
                    onTomorrow = {
                        vm.saveSession(
                            session.copy(
                                startMillis = session.startMillis + DAY_MS,
                                endMillis = session.endMillis + DAY_MS
                            )
                        )
                    },
                    onDelete = { deleting = session }
                )
            }
        }
    }

    if (adding) {
        SessionDialog(
            initial = null,
            defaultDate = today,
            subjects = subjects,
            chapters = chapters,
            onDismiss = { adding = false },
            onSave = {
                vm.saveSession(it)
                adding = false
            }
        )
    }
    editing?.let { session ->
        SessionDialog(
            initial = session,
            defaultDate = today,
            subjects = subjects,
            chapters = chapters,
            onDismiss = { editing = null },
            onSave = {
                vm.saveSession(it)
                editing = null
            }
        )
    }
    deleting?.let { session ->
        ConfirmDeleteDialog(
            what = session.title.ifBlank { "Study session" },
            onConfirm = {
                vm.deleteSession(session)
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }
    if (goalDialog) {
        NameDialog(
            title = "Daily study goal",
            label = "Minutes (15 se 1440)",
            initial = goal.toString(),
            numeric = true,
            onDismiss = { goalDialog = false },
            onSave = { text ->
                val minutes = text.toIntOrNull()
                if (minutes != null && minutes in 15..1440) vm.setGoal(minutes)
                goalDialog = false
            }
        )
    }
}
