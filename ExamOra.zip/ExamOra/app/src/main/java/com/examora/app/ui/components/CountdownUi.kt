package com.examora.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.data.ExamEntity
import com.examora.app.ui.theme.ExamBlue
import com.examora.app.ui.theme.ExamGreen
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamPurple
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamSurfaceHigh
import com.examora.app.ui.theme.ExamTeal
import com.examora.app.ui.theme.ExamTextSoft
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Locale

/** A countdown theme: four colours for days / hours / minutes / seconds. */
data class CountdownTheme(val name: String, val colors: List<Color>)

val countdownThemes = listOf(
    CountdownTheme("Classic", listOf(ExamOrange, ExamPurple, ExamBlue, ExamTeal)),
    CountdownTheme("Orange", List(4) { ExamOrange }),
    CountdownTheme("Purple", List(4) { ExamPurple }),
    CountdownTheme("Blue", List(4) { ExamBlue }),
    CountdownTheme("Teal", List(4) { ExamTeal }),
    CountdownTheme("Green", List(4) { ExamGreen })
)

/** Current time, refreshed every second. */
@Composable
fun rememberNow(): Long {
    val now by produceState(initialValue = System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000)
        }
    }
    return now
}

fun formatExamDate(millis: Long): String =
    SimpleDateFormat("EEE, d MMM yyyy  hh:mm a", Locale.getDefault()).format(millis)

@Composable
fun ExamCard(
    exam: ExamEntity,
    now: Long,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    actions: (@Composable RowScope.() -> Unit)? = null
) {
    val theme = countdownThemes[exam.themeIndex.coerceIn(0, countdownThemes.lastIndex)]
    val accent = theme.colors[0]
    val label = when {
        exam.isEvent -> "Event"
        exam.attempt > 1 -> "Exam  |  Attempt ${exam.attempt}"
        else -> "Exam"
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(ExamSurface)
            .padding(if (compact) 16.dp else 20.dp)
    ) {
        Text(label, color = accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(4.dp))
        Text(
            exam.name,
            fontSize = if (compact) 17.sp else 22.sp,
            fontWeight = FontWeight.Bold
        )
        Text(formatExamDate(exam.timeMillis), color = ExamTextSoft, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp))

        val diff = exam.timeMillis - now
        if (diff <= 0) {
            Text("Ho chuka hai", color = ExamTeal, fontWeight = FontWeight.SemiBold)
        } else {
            val totalSec = diff / 1000
            val days = totalSec / 86400
            val hours = (totalSec % 86400) / 3600
            val mins = (totalSec % 3600) / 60
            val secs = totalSec % 60
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TimeBox("Days", days, theme.colors[0], compact, Modifier.weight(1f))
                TimeBox("Hours", hours, theme.colors[1], compact, Modifier.weight(1f))
                TimeBox("Min", mins, theme.colors[2], compact, Modifier.weight(1f))
                TimeBox("Sec", secs, theme.colors[3], compact, Modifier.weight(1f))
            }
        }

        if (actions != null) {
            Row(
                modifier = Modifier.padding(top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                actions()
            }
        }
    }
}

@Composable
private fun TimeBox(
    label: String,
    value: Long,
    color: Color,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(ExamSurfaceHigh)
            .padding(vertical = if (compact) 8.dp else 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            value.toString().padStart(2, '0'),
            fontSize = if (compact) 18.sp else 24.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
        Text(label, fontSize = 11.sp, color = ExamTextSoft)
    }
}
