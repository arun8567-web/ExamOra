# ExamOra (Phase 3: Planner + To-Do + Calendar)

Plan Smart. Study Better. Achieve More.

## Abhi kya kaam karta hai
- Dark premium theme, launcher icon, splash screen, 5-tab bottom navigation
- Home: greeting, date, next exam ka live countdown, aur 3 tak aur upcoming exam cards, motivation quote
- Exams & Events screen (Home -> "Sab exams manage karo"): multiple exams / events, attempts, 6 countdown themes,
  reorder, upcoming / completed, notifications (1 din pehle + exam ke time par)
- Home-screen widget (1 design): next exam ka naam, days left, live H:MM:SS timer.
  Widgets tab ke button se ya home screen long-press > Widgets > ExamOra se lagta hai.

### Planner tab (naya, Phase 3)
- **Sessions**: study session add / edit / delete, subject + chapter chunna, date, start & end time, priority,
  done / pending. "Kal par shift karo" se ek tap me reschedule. Filter: Aaj / Is hafte / Sab (daily + weekly schedule).
  Daily study goal (minutes) aur aaj ka goal progress bar.
- **Calendar**: month grid, session wale din aur task deadline wale din par dot, din tap karke us din ka schedule dekho
  aur wahin session add karo.
- **To-Do**: task add / edit / delete, deadline, priority, category (Study / Revision / Test / Homework / Other),
  subject, done tracking. Sections: Overdue, Aaj, Aage, Completed. Aaj ka progress bar.
- **Subjects**: subjects (color ke saath) aur unke chapters, chapter complete tick.
- Session reminder: session se 10 minute pehle notification (WorkManager).
- Sab data alag `planner.db` me save hota hai. Exam database ko chheda nahi gaya.

## Limits (honest)
- Widget abhi sirf 1 design ka hai. 160 designs ki gallery aur per-widget settings baad me.
- Notification kabhi kabhi kuch minute late aa sakta hai (battery saver / Doze).
- Task deadline ka notification abhi nahi hai (sirf exam aur study session ke reminders hain).
- Recurring sessions / weekly repeat abhi nahi hai. Har session alag add hota hai.
- Session ek hi din ke andar (start aur end same date) ka hota hai.
- Progress, Settings tabs abhi "Abhi built nahi hai" dikhate hain.
- Ye code abhi kisi build ya device par test nahi hua.

## Phone se APK banane ke steps
1. GitHub repo me purani `ExamOra.zip` ki jagah nayi `ExamOra.zip` upload karo (same naam = replace). Extract MAT karo.
2. `.github/workflows/build.yml` pehle se hai, usko badalne ki zarurat nahi.
3. Commit ke baad Actions tab me build chalega. Green tick aane ka wait karo, phir Artifacts se APK download karo.
4. Purane app ke upar hi install kar do, data bacha rahega.
