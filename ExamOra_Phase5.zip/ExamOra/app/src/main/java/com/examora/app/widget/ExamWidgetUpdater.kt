package com.examora.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.LinearGradient
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.examora.app.MainActivity
import com.examora.app.R
import com.examora.app.data.AppDatabase
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Draws the countdown widget for every placed instance.
 *
 * Days left are plain text. The remaining time inside the current day is a countdown
 * Chronometer, which keeps ticking live without waking the app. A WorkManager job redraws
 * the widget exactly when the day count changes, and whenever exam data changes.
 */
object ExamWidgetUpdater {
    private const val WORK_NAME = "widget_refresh"
    private const val DAY_MS = 24L * 60 * 60 * 1000

    /** Redraw soon (called when data changes or a widget is added). */
    fun refresh(context: Context) {
        val request = OneTimeWorkRequestBuilder<ExamWidgetWorker>().build()
        WorkManager.getInstance(context)
            .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }

    private fun scheduleNext(context: Context, delayMs: Long) {
        val request = OneTimeWorkRequestBuilder<ExamWidgetWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context)
            .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request)
    }


    private fun createWidgetBackground(background: Int, accent: Int, layout: Int): Bitmap {
        val width = 720
        val height = 360
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val darkAccent = android.graphics.Color.rgb(
            (android.graphics.Color.red(accent) * 0.34f).toInt(),
            (android.graphics.Color.green(accent) * 0.34f).toInt(),
            (android.graphics.Color.blue(accent) * 0.34f).toInt()
        )
        val endColor = when (layout) {
            0 -> background
            1 -> darkAccent
            2 -> blend(background, accent, 0.20f)
            3 -> blend(background, accent, 0.10f)
            else -> background
        }
        paint.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), background, endColor, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 54f, 54f, paint)
        paint.shader = null
        if (layout == 1 || layout == 4) {
            paint.color = accent
            paint.alpha = 90
            canvas.drawCircle(width - 70f, 55f, 120f, paint)
        } else if (layout == 3) {
            paint.color = accent
            paint.alpha = 70
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            canvas.drawRoundRect(RectF(12f, 12f, width - 12f, height - 12f), 48f, 48f, paint)
        }
        return bitmap
    }

    private fun blend(from: Int, to: Int, amount: Float): Int {
        fun channel(a: Int, b: Int) = (a + (b - a) * amount).toInt().coerceIn(0, 255)
        return android.graphics.Color.rgb(
            channel(android.graphics.Color.red(from), android.graphics.Color.red(to)),
            channel(android.graphics.Color.green(from), android.graphics.Color.green(to)),
            channel(android.graphics.Color.blue(from), android.graphics.Color.blue(to))
        )
    }

    /** Redraws all widgets, then schedules the next redraw. */
    suspend fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, ExamWidgetProvider::class.java))
        if (ids.isEmpty()) return

        val now = System.currentTimeMillis()
        val next = AppDatabase.get(context).examDao().getAll()
            .filter { it.timeMillis > now }
            .minByOrNull { it.timeMillis }

        val views = RemoteViews(context.packageName, R.layout.widget_countdown)
        val style = WidgetStyles.selected(context)
        views.setImageViewBitmap(R.id.w_background, createWidgetBackground(style.background.toInt(), style.accent.toInt(), style.layout))
        views.setTextColor(R.id.w_label, style.accent.toInt())
        views.setTextColor(R.id.w_days, style.accent.toInt())
        views.setTextColor(R.id.w_name, style.text.toInt())
        views.setTextColor(R.id.w_chrono, style.text.toInt())
        views.setTextColor(R.id.w_days_unit, style.muted.toInt())
        views.setTextColor(R.id.w_date, style.muted.toInt())
        views.setTextViewTextSize(R.id.w_days, android.util.TypedValue.COMPLEX_UNIT_SP,
            if (style.layout == 1) 42f else if (style.layout == 3) 32f else 36f)
        var nextDelay: Long? = null

        if (next == null) {
            views.setTextViewText(R.id.w_label, "ExamOra")
            views.setTextViewText(R.id.w_name, "Koi upcoming exam nahi")
            views.setTextViewText(R.id.w_days, "--")
            views.setTextViewText(R.id.w_days_unit, "")
            views.setViewVisibility(R.id.w_chrono, View.GONE)
            views.setTextViewText(R.id.w_date, "App kholke exam add karo")
        } else {
            val diff = next.timeMillis - now
            val days = diff / DAY_MS
            val remainder = diff % DAY_MS

            views.setTextViewText(R.id.w_label, if (next.isEvent) "EVENT • ${style.category.uppercase(Locale.getDefault())}" else "EXAM • ${style.category.uppercase(Locale.getDefault())}")
            views.setTextViewText(R.id.w_name, next.name)
            views.setTextViewText(R.id.w_days, days.toString())
            views.setTextViewText(R.id.w_days_unit, if (days == 1L) "day left" else "days left")
            views.setViewVisibility(R.id.w_chrono, View.VISIBLE)
            views.setChronometerCountDown(R.id.w_chrono, true)
            views.setChronometer(
                R.id.w_chrono,
                SystemClock.elapsedRealtime() + remainder,
                null,
                true
            )
            views.setTextViewText(
                R.id.w_date,
                SimpleDateFormat("EEE, d MMM yyyy  hh:mm a", Locale.getDefault())
                    .format(next.timeMillis)
            )
            nextDelay = maxOf(remainder + 5_000L, 30_000L)
        }

        val openApp = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.w_root, openApp)

        manager.updateAppWidget(ids, views)
        if (nextDelay != null) scheduleNext(context, nextDelay)
    }
}

class ExamWidgetWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        ExamWidgetUpdater.updateAll(applicationContext)
        return Result.success()
    }
}
