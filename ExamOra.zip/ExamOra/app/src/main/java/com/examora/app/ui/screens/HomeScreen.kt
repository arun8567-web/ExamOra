package com.examora.app.ui.screens

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.data.Exam
import com.examora.app.data.ExamStore
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamBlue
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamPurple
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamSurfaceHigh
import com.examora.app.ui.theme.ExamTeal
import com.examora.app.ui.theme.ExamTextSoft
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale

private val quotes = listOf(
    "Roz thoda sa padhna, ek din bahut bada result banata hai.",
    "Discipline motivation se zyada der tak chalta hai.",
    "Aaj ka kaam kal pe mat chhodo, kal ka tum thank you bologe.",
    "Consistency > intensity. Har din 1% better.",
    "Mushkil sawal wahi hai jo abhi tak practice nahi kiya.",
    "Exam se pehle ka har ghanta ginti me aata hai.",
    "Gir gaye to kya, revision se wapas uth sakte ho."
)

@Composable
fun HomeScreen(onOpenTab: (String) -> Unit) {
    val context = LocalContext.current
    val store = remember { ExamStore(context) }
    var exam by remember { mutableStateOf(store.load()) }
    var showDialog by remember { mutableStateOf(false) }
    var quoteIndex by remember { mutableStateOf(store.quoteIndex() % quotes.size) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Header()

        CountdownCard(
            exam = exam,
            onAdd = { showDialog = true },
            onEdit = { showDialog = true },
            onDelete = {
                store.clear()
                exam = null
            }
        )

        QuickAccessRow(onOpenTab)

        QuoteCard(
            quote = quotes[quoteIndex],
            onNext = {
                quoteIndex = (quoteIndex + 1) % quotes.size
                store.saveQuoteIndex(quoteIndex)
            }
        )
    }

    if (showDialog) {
        ExamDialog(
            initial = exam,
            onDismiss = { showDialog = false },
            onSave = { saved ->
                store.save(saved)
                exam = saved
                showDialog = false
            }
        )
    }
}

@Composable
private fun Header() {
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..20 -> "Good evening"
        else -> "Good night"
    }
    val date = remember {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()))
    }
    Column {
        Text("ExamOra", color = ExamOrange, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(greeting, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(date, color = ExamTextSoft, fontSize = 14.sp)
        Text("Plan Smart. Study Better. Achieve More.", color = ExamTextSoft, fontSize = 12.sp)
    }
}

@Composable
private fun CountdownCard(
    exam: Exam?,
    onAdd: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(ExamSurface)
            .padding(20.dp)
    ) {
        Text("Next exam", color = ExamTextSoft, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))

        if (exam == null) {
            Text("Koi exam set nahi hai", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onAdd,
                colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
            ) { Text("Exam add karo") }
        } else {
            Text(exam.name, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp))

            val diff = exam.timeMillis - now
            if (diff <= 0) {
                Text("Exam ho chuka hai", color = ExamTeal, fontWeight = FontWeight.SemiBold)
            } else {
                val totalSec = diff / 1000
                val days = totalSec / 86400
                val hours = (totalSec % 86400) / 3600
                val mins = (totalSec % 3600) / 60
                val secs = totalSec % 60
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TimeBox("Days", days, ExamOrange, Modifier.weight(1f))
                    TimeBox("Hours", hours, ExamPurple, Modifier.weight(1f))
                    TimeBox("Min", mins, ExamBlue, Modifier.weight(1f))
                    TimeBox("Sec", secs, ExamTeal, Modifier.weight(1f))
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onEdit) { Text("Edit") }
                OutlinedButton(onClick = onDelete) { Text("Delete") }
            }
        }
    }
}

@Composable
private fun TimeBox(label: String, value: Long, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(ExamSurfaceHigh)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(value.toString().padStart(2, '0'), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = color)
        Text(label, fontSize = 11.sp, color = ExamTextSoft)
    }
}

@Composable
private fun QuickAccessRow(onOpenTab: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Quick access", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickItem("Planner", Icons.Filled.DateRange, ExamBlue, Modifier.weight(1f)) { onOpenTab("planner") }
            QuickItem("Widgets", Icons.Filled.Widgets, ExamPurple, Modifier.weight(1f)) { onOpenTab("widgets") }
            QuickItem("Progress", Icons.Filled.BarChart, ExamTeal, Modifier.weight(1f)) { onOpenTab("progress") }
        }
    }
}

@Composable
private fun QuickItem(
    label: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(ExamSurface)
            .clickable(onClick = onClick)
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, contentDescription = label, tint = tint)
        Text(label, fontSize = 13.sp)
    }
}

@Composable
private fun QuoteCard(quote: String, onNext: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(ExamSurface)
            .padding(20.dp)
    ) {
        Text("Motivation", color = ExamOrange, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(quote, fontSize = 17.sp)
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onNext) { Text("Next quote", color = ExamOrange) }
    }
}

@Composable
private fun ExamDialog(initial: Exam?, onDismiss: () -> Unit, onSave: (Exam) -> Unit) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initial?.name ?: "") }
    val cal = remember {
        Calendar.getInstance().apply {
            if (initial != null) {
                timeInMillis = initial.timeMillis
            } else {
                add(Calendar.DAY_OF_YEAR, 30)
                set(Calendar.HOUR_OF_DAY, 9)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
        }
    }
    var millis by remember { mutableLongStateOf(cal.timeInMillis) }

    val shown = remember(millis) {
        java.text.SimpleDateFormat("d MMM yyyy, hh:mm a", Locale.getDefault()).format(millis)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Exam add karo" else "Exam edit karo") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Exam name (e.g. JEE Main 2027)") },
                    singleLine = true
                )
                Text("Date & time: $shown", color = ExamTextSoft)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = millis }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val u = Calendar.getInstance().apply {
                                    timeInMillis = millis
                                    set(y, m, d)
                                }
                                millis = u.timeInMillis
                            },
                            c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }) { Text("Date") }
                    OutlinedButton(onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = millis }
                        TimePickerDialog(
                            context,
                            { _, h, min ->
                                val u = Calendar.getInstance().apply {
                                    timeInMillis = millis
                                    set(Calendar.HOUR_OF_DAY, h)
                                    set(Calendar.MINUTE, min)
                                    set(Calendar.SECOND, 0)
                                }
                                millis = u.timeInMillis
                            },
                            c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false
                        ).show()
                    }) { Text("Time") }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = { onSave(Exam(name.trim(), millis)) }
            ) { Text("Save", color = ExamOrange) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
