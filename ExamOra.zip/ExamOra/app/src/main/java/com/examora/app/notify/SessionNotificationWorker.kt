package com.examora.app.notify

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.examora.app.MainActivity
import com.examora.app.R

class SessionNotificationWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val label = inputData.getString("label") ?: return Result.success()
        val id = inputData.getLong("id", 0L)
        val lead = inputData.getBoolean("lead", true)

        val ctx = applicationContext
        SessionNotifier.createChannel(ctx)

        val text = if (lead) {
            "$label session 10 minute me shuru hoga."
        } else {
            "$label session ka time ho gaya."
        }

        val openApp = PendingIntent.getActivity(
            ctx,
            0,
            Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(ctx, SessionNotifier.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_examora)
            .setContentTitle("Study session")
            .setContentText(text)
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .build()

        try {
            val manager = NotificationManagerCompat.from(ctx)
            if (manager.areNotificationsEnabled()) {
                manager.notify((1_000_000L + id).toInt(), notification)
            }
        } catch (e: SecurityException) {
            // Notification permission not granted; nothing to show.
        }
        return Result.success()
    }
}
