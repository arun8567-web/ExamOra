package com.examora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.data.planner.FocusSessionEntity
import com.examora.app.ui.PlannerViewModel
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamBlue
import com.examora.app.ui.theme.ExamGreen
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamPurple
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamSurfaceHigh
import com.examora.app.ui.theme.ExamTeal
import com.examora.app.ui.theme.ExamTextSoft
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.WeekFields
import java.util.Locale

private enum class ProgressRange { DAY, WEEK, MONTH }

@Composable
fun ProgressScreen(vm: PlannerViewModel) {
    val focus by vm.focusSessions.collectAsState()
    val subjects by vm.subjects.collectAsState()
    val chapters by vm.chapters.collectAsState()
    val todos by vm.todos.collectAsState()
    val sessions by vm.sessions.collectAsState()
    val goal by vm.dailyGoalMinutes.collectAsState()
    var range by remember { mutableIntStateOf(1) }

    val today = LocalDate.now()
    val zone = ZoneId.systemDefault()
    fun dateOf(record: FocusSessionEntity): LocalDate =
        Instant.ofEpochMilli(record.startedAtMillis).atZone(zone).toLocalDate()
    val focusRecords = focus.filter { it.mode == "Focus" && it.actualSeconds > 0 }
    val todayRecords = focusRecords.filter { dateOf(it) == today }
    val todayMinutes = todayRecords.sumOf { it.actualSeconds } / 60
    val goalRatio = if (goal > 0) (todayMinutes.toFloat() / goal).coerceIn(0f, 1f) else 0f

    val startDate = when (ProgressRange.values()[range]) {
        ProgressRange.DAY -> today
        ProgressRange.WEEK -> today.minusDays(6)
        ProgressRange.MONTH -> today.withDayOfMonth(1)
    }
    val rangeRecords = focusRecords.filter { dateOf(it) >= startDate && dateOf(it) <= today }
    val rangeMinutes = rangeRecords.sumOf { it.actualSeconds } / 60
    val rangeDays = when (ProgressRange.values()[range]) {
        ProgressRange.DAY -> 1
        ProgressRange.WEEK -> 7
        ProgressRange.MONTH -> today.dayOfMonth
    }
    val completedTasks = todos.count { it.done }
    val totalTasks = todos.size
    val completedPlanned = sessions.count { it.done }
    val totalPlanned = sessions.size
    val completedChapters = chapters.count { it.done }
    val totalChapters = chapters.size

    val streak = remember(focus) {
        var count = 0
        var date = today
        val activeDates = focusRecords.map { dateOf(it) }.toSet()
        if (today !in activeDates) date = today.minusDays(1)
        while (date in activeDates) {
            count++
            date = date.minusDays(1)
        }
        count
    }

    Column(
        modifier = Modifier.fillMaxSize().background(ExamBg)
            .verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Your Progress", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        Text("Your study effort, saved automatically from Focus sessions.", color = ExamTextSoft, fontSize = 13.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Day", "7 Days", "Month").forEachIndexed { index, label ->
                FilterChip(selected = range == index, onClick = { range = index }, label = { Text(label) })
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Study time", formatMinutes(todayMinutes), "Today", ExamGreen, Modifier.weight(1f))
            MetricCard("Sessions", todayRecords.size.toString(), "Completed today", ExamBlue, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard("Study streak", "$streak days", "In a row", ExamOrange, Modifier.weight(1f))
            MetricCard("Daily goal", "${(goalRatio * 100).toInt()}%", "${formatMinutes(goal)} target", ExamPurple, Modifier.weight(1f))
        }

        SectionCard("Daily goal") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${formatMinutes(todayMinutes)} studied", fontWeight = FontWeight.SemiBold)
                Text("${formatMinutes(goal)} goal", color = ExamTextSoft)
            }
            LinearProgressIndicator(
                progress = { goalRatio }, modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape),
                color = ExamOrange, trackColor = ExamSurfaceHigh
            )
            Text(if (goalRatio >= 1f) "Daily target completed. Great work!" else "${formatMinutes((goal - todayMinutes).coerceAtLeast(0))} left to reach your goal", color = ExamTextSoft, fontSize = 12.sp)
        }

        SectionCard(when (range) { 0 -> "Today's focus"; 1 -> "Last 7 days"; else -> "This month" }) {
            val bars = when (range) {
                0 -> listOf(today)
                1 -> (6 downTo 0).map { today.minusDays(it.toLong()) }
                else -> (1..today.dayOfMonth).map { today.withDayOfMonth(it) }
            }
            val values = bars.map { day -> focusRecords.filter { dateOf(it) == day }.sumOf { it.actualSeconds } / 60 }
            val maxValue = (values.maxOrNull() ?: 0).coerceAtLeast(30)
            Row(
                modifier = Modifier.fillMaxWidth().height(130.dp),
                horizontalArrangement = Arrangement.spacedBy(if (range == 2) 2.dp else 8.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                bars.forEachIndexed { index, day ->
                    Column(
                        modifier = Modifier.weight(1f).height(130.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom
                    ) {
                        if (range != 2 || day.dayOfMonth % 5 == 0 || day == today) {
                            Text(if (values[index] == 0) "" else values[index].toString(), fontSize = 9.sp, color = ExamTextSoft)
                        }
                        val fraction = values[index].toFloat() / maxValue
                        Box(
                            Modifier.fillMaxWidth(if (range == 2) 0.82f else 0.72f)
                                .height((8 + fraction * 78).dp.coerceAtMost(88.dp))
                                .clip(RoundedCornerShape(topStart = 5.dp, topEnd = 5.dp))
                                .background(if (day == today) ExamOrange else ExamBlue)
                        )
                        Spacer(Modifier.height(5.dp))
                        if (range == 0) Text("Today", fontSize = 10.sp, color = ExamTextSoft)
                        else if (range == 1 || day.dayOfMonth % 5 == 0 || day == today) Text(if (range == 1) day.dayOfWeek.name.take(2) else day.dayOfMonth.toString(), fontSize = 9.sp, color = ExamTextSoft)
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total: ${formatMinutes(rangeMinutes)}", fontWeight = FontWeight.SemiBold, color = ExamGreen)
                Text("Avg: ${formatMinutes(if (rangeDays > 0) rangeMinutes / rangeDays else 0)}/day", color = ExamTextSoft, fontSize = 12.sp)
            }
        }

        SectionCard("Subject-wise focus") {
            if (subjects.isEmpty()) Text("Add subjects in Planner to see subject analytics.", color = ExamTextSoft, fontSize = 13.sp)
            else subjects.forEachIndexed { index, subject ->
                val minutes = focusRecords.filter { it.subjectId == subject.id }.sumOf { it.actualSeconds } / 60
                val total = focusRecords.sumOf { it.actualSeconds } / 60
                val ratio = if (total > 0) minutes.toFloat() / total else 0f
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(subject.name, fontWeight = FontWeight.Medium)
                        Text(formatMinutes(minutes), color = ExamTextSoft, fontSize = 12.sp)
                    }
                    LinearProgressIndicator(
                        progress = { ratio }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape),
                        color = listOf(ExamOrange, ExamBlue, ExamPurple, ExamTeal, ExamGreen)[index % 5],
                        trackColor = ExamSurfaceHigh
                    )
                }
            }
        }

        SectionCard("Planner completion") {
            CompletionRow("To-do tasks", completedTasks, totalTasks)
            CompletionRow("Study sessions", completedPlanned, totalPlanned)
            CompletionRow("Chapters", completedChapters, totalChapters)
        }

        SectionCard("Recent focus sessions") {
            val recent = focusRecords.take(6)
            if (recent.isEmpty()) Text("Complete a Focus timer to start building your progress history.", color = ExamTextSoft, fontSize = 13.sp)
            recent.forEach { record ->
                val subject = subjects.firstOrNull { it.id == record.subjectId }?.name ?: "General study"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(subject, fontWeight = FontWeight.Medium)
                        Text(dateOf(record).toString(), color = ExamTextSoft, fontSize = 11.sp)
                    }
                    Text(formatMinutes(record.actualSeconds / 60), color = ExamGreen, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun MetricCard(title: String, value: String, subtitle: String, color: Color, modifier: Modifier = Modifier) {
    Column(modifier.clip(RoundedCornerShape(18.dp)).background(ExamSurface).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(title, color = ExamTextSoft, fontSize = 12.sp)
        Text(value, color = color, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = ExamTextSoft, fontSize = 10.sp)
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(ExamSurface).padding(15.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        content()
    }
}

@Composable
private fun CompletionRow(label: String, done: Int, total: Int) {
    val ratio = if (total > 0) done.toFloat() / total else 0f
    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text("$done / $total", color = ExamTextSoft, fontSize = 12.sp)
        }
        LinearProgressIndicator(progress = { ratio }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = ExamTeal, trackColor = ExamSurfaceHigh)
    }
}

private fun formatMinutes(minutes: Int): String =
    if (minutes < 60) "$minutes min" else "${minutes / 60}h ${minutes % 60}m"
