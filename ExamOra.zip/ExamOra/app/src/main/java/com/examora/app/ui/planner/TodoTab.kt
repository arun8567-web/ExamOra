package com.examora.app.ui.planner

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.data.planner.SubjectEntity
import com.examora.app.data.planner.TodoEntity
import com.examora.app.ui.PlannerViewModel
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamRed
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamSurfaceHigh
import com.examora.app.ui.theme.ExamTextSoft
import com.examora.app.util.formatDateTime
import com.examora.app.util.startMillis
import com.examora.app.util.todayDate

@Composable
fun TodoRow(
    todo: TodoEntity,
    subject: SubjectEntity?,
    now: Long,
    onToggle: () -> Unit,
    onEdit: (() -> Unit)?,
    onDelete: (() -> Unit)?
) {
    val overdue = !todo.done && todo.deadlineMillis != 0L && todo.deadlineMillis < now
    val parts = mutableListOf(todo.category)
    if (subject != null) parts.add(subject.name)
    if (todo.deadlineMillis != 0L) parts.add(formatDateTime(todo.deadlineMillis))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(ExamSurface)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Checkbox(
            checked = todo.done,
            onCheckedChange = { onToggle() },
            colors = CheckboxDefaults.colors(checkedColor = ExamOrange)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                todo.title,
                fontWeight = FontWeight.SemiBold,
                textDecoration = if (todo.done) TextDecoration.LineThrough else null
            )
            Text(
                parts.joinToString("  |  "),
                color = if (overdue) ExamRed else ExamTextSoft,
                fontSize = 12.sp
            )
            Text(
                priorityLabel(todo.priority),
                color = priorityColor(todo.priority),
                fontSize = 12.sp
            )
        }
        if (onEdit != null) {
            IconButton(onClick = onEdit) {
                Icon(Icons.Filled.Edit, contentDescription = "Edit")
            }
        }
        if (onDelete != null) {
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete")
            }
        }
    }
}

private fun LazyListScope.todoSection(
    title: String,
    list: List<TodoEntity>,
    emptyText: String,
    subjectMap: Map<Long, SubjectEntity>,
    now: Long,
    onToggle: (TodoEntity) -> Unit,
    onEdit: (TodoEntity) -> Unit,
    onDelete: (TodoEntity) -> Unit
) {
    item { SectionHeader(title) }
    if (list.isEmpty()) {
        item { Text(emptyText, color = ExamTextSoft, fontSize = 13.sp) }
    }
    items(list) { todo ->
        TodoRow(
            todo = todo,
            subject = subjectMap[todo.subjectId],
            now = now,
            onToggle = { onToggle(todo) },
            onEdit = { onEdit(todo) },
            onDelete = { onDelete(todo) }
        )
    }
}

@Composable
fun TodoTab(vm: PlannerViewModel) {
    val todos by vm.todos.collectAsState()
    val subjects by vm.subjects.collectAsState()

    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<TodoEntity?>(null) }
    var deleting by remember { mutableStateOf<TodoEntity?>(null) }

    val subjectMap = remember(subjects) { subjects.associateBy { it.id } }
    val today = todayDate()
    val dayStart = today.startMillis()
    val dayEnd = dayStart + DAY_MS
    val now = com.examora.app.ui.components.rememberNow()

    val overdue = todos
        .filter { !it.done && it.deadlineMillis != 0L && it.deadlineMillis < now }
        .sortedBy { it.deadlineMillis }
    val dueToday = todos
        .filter { !it.done && it.deadlineMillis >= now && it.deadlineMillis in dayStart until dayEnd }
        .sortedBy { it.deadlineMillis }
    val later = todos
        .filter { !it.done && (it.deadlineMillis == 0L || it.deadlineMillis >= dayEnd) }
        .sortedWith(compareBy<TodoEntity>({ it.deadlineMillis == 0L }, { it.deadlineMillis }))
    val completed = todos.filter { it.done }

    val todayAll = todos.filter { it.deadlineMillis in dayStart until dayEnd }
    val todayDone = todayAll.count { it.done }
    val fraction = if (todayAll.isEmpty()) 0f else todayDone.toFloat() / todayAll.size
    val totalDone = completed.size
    val todayText = if (todayAll.isEmpty()) {
        "Aaj koi task due nahi hai."
    } else {
        "$todayDone / ${todayAll.size} tasks complete"
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, top = 12.dp, end = 20.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(ExamSurface)
                    .padding(16.dp)
            ) {
                Text("Aaj ka task progress", fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    todayText + "   (kul complete: $totalDone / ${todos.size})",
                    color = ExamTextSoft,
                    fontSize = 13.sp
                )
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { fraction },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = ExamOrange,
                    trackColor = ExamSurfaceHigh
                )
            }
        }
        item {
            Button(
                onClick = { adding = true },
                colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
            ) { Text("Task add karo") }
        }

        todoSection(
            "Overdue (${overdue.size})", overdue, "Koi overdue task nahi. Badhiya!",
            subjectMap, now, { vm.toggleTodo(it) }, { editing = it }, { deleting = it }
        )
        todoSection(
            "Aaj (${dueToday.size})", dueToday, "Aaj ke liye koi pending task nahi.",
            subjectMap, now, { vm.toggleTodo(it) }, { editing = it }, { deleting = it }
        )
        todoSection(
            "Aage / bina deadline (${later.size})", later, "Kuch nahi.",
            subjectMap, now, { vm.toggleTodo(it) }, { editing = it }, { deleting = it }
        )
        todoSection(
            "Completed (${completed.size})", completed, "Abhi koi task complete nahi hua.",
            subjectMap, now, { vm.toggleTodo(it) }, { editing = it }, { deleting = it }
        )
    }

    if (adding) {
        TodoDialog(
            initial = null,
            defaultDate = today,
            subjects = subjects,
            onDismiss = { adding = false },
            onSave = {
                vm.saveTodo(it)
                adding = false
            }
        )
    }
    editing?.let { todo ->
        TodoDialog(
            initial = todo,
            defaultDate = today,
            subjects = subjects,
            onDismiss = { editing = null },
            onSave = {
                vm.saveTodo(it)
                editing = null
            }
        )
    }
    deleting?.let { todo ->
        ConfirmDeleteDialog(
            what = todo.title,
            onConfirm = {
                vm.deleteTodo(todo)
                deleting = null
            },
            onDismiss = { deleting = null }
        )
    }
}
