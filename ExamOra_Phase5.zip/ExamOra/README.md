# ExamOra (Phase 3: Planner + To-Do + Calendar)

Plan Smart. Study Better. Achieve More.

## Abhi kya kaam karta hai
- Dark premium theme, launcher icon, splash screen, 5-tab bottom navigation
- Home: greeting, date, next exam ka live countdown, aur 3 tak aur upcoming exam cards, motivation quote
- Exams & Events screen (Home -> "Sab exams manage karo"): multiple exams / events, attempts, 6 countdown themes,
  reorder, upcoming / completed, notifications (1 din pehle + exam ke time par)
- Home-screen widget (1 design): next exam ka naam, days left, live H:MM:SS timer.
  Widgets tab ke button se ya home screen long-press > Widgets > ExamOra se lagta hai.

### Planner tab (naya, Phase 3)
- **Sessions**: study session add / edit / delete, subject + chapter chunna, date, start & end time, priority,
  done / pending. "Kal par shift karo" se ek tap me reschedule. Filter: Aaj / Is hafte / Sab (daily + weekly schedule).
  Daily study goal (minutes) aur aaj ka goal progress bar.
- **Calendar**: month grid, session wale din aur task deadline wale din par dot, din tap karke us din ka schedule dekho
  aur wahin session add karo.
- **To-Do**: task add / edit / delete, deadline, priority, category (Study / Revision / Test / Homework / Other),
  subject, done tracking. Sections: Overdue, Aaj, Aage, Completed. Aaj ka progress bar.
- **Subjects**: subjects (color ke saath) aur unke chapters, chapter complete tick.
- Session reminder: session se 10 minute pehle notification (WorkManager).
- Sab data alag `planner.db` me save hota hai. Exam database ko chheda nahi gaya.

## Phase 5 – Widget Style Gallery
- Widget Gallery with 9 design families: Aesthetic, Nature, Glassy, Tricolor, Study, Dark, Anime, Countdown and Neon.
- 20 named presets per family (180 total), based on the user's supplied design sheets.
- Gallery has category filters, selectable previews, selected-state indicator and Apply action.
- Applying a style persists the selected preset and refreshes the actual Android home-screen countdown widget.
- The home-screen widget keeps live exam data and changes its palette / visual treatment with the selected style.
- Daily study goal continues to support Hours or Minutes input (stored internally as minutes).

## Limits (honest)
- 180 presets are currently palette/layout variants in the supplied design families; they are not 180 individually hand-painted image backgrounds. Android RemoteViews applies supported native widget styling and live text.
- Notification kabhi kabhi kuch minute late aa sakta hai (battery saver / Doze).
- Task deadline ka notification abhi nahi hai (sirf exam aur study session ke reminders hain).
- Recurring sessions / weekly repeat abhi nahi hai. Har session alag add hota hai.
- Session ek hi din ke andar (start aur end same date) ka hota hai.
- Progress, Settings tabs abhi "Abhi built nahi hai" dikhate hain.
- Ye code abhi kisi build ya device par test nahi hua.

## Phone se APK banane ke steps
1. GitHub repo me purani `ExamOra.zip` ki jagah nayi `ExamOra.zip` upload karo (same naam = replace). Extract MAT karo.
2. `.github/workflows/build.yml` pehle se hai, usko badalne ki zarurat nahi.
3. Commit ke baad Actions tab me build chalega. Green tick aane ka wait karo, phir Artifacts se APK download karo.
4. Purane app ke upar hi install kar do, data bacha rahega.


## Version 0.4.0 – Phase 4
- Added Focus tab inside Planner with Focus, Short Break and Long Break modes.
- Added 25-minute default focus timer, custom 1–180 minute duration, Start/Pause/Resume/Reset.
- Completed focus and break sessions are saved in the planner database.
- Added subject selection, recent focus history and today's focus totals.
- Added focus-completion notifications (Android notification permission must be enabled).
- Added a safe Room migration from planner.db version 1 to version 2 for focus history.
- Daily study goal now supports Hours or Minutes input; values continue to be stored as minutes.
- Timer execution is in-app; a process kill can interrupt an active timer. Background-resilient timer service is not included in this release.


## Version 0.5.0 – Phase 5
- Added 180-style widget gallery across 9 supplied design families.
- Added style selection persistence and Apply action.
- Applying a style refreshes the real Android home-screen countdown widget while preserving live exam countdown data.
