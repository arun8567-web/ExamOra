package com.examora.app.data.planner

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val colorIndex: Int = 0
)

@Entity(tableName = "chapters")
data class ChapterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val subjectId: Long,
    val name: String,
    val done: Boolean = false
)

/** One planned study block. subjectId / chapterId 0 means "none". */
@Entity(tableName = "sessions")
data class StudySessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String = "",
    val subjectId: Long = 0,
    val chapterId: Long = 0,
    val startMillis: Long,
    val endMillis: Long,
    val priority: Int = 1,
    val done: Boolean = false
)

/** To-do task. deadlineMillis 0 means "no deadline". */
@Entity(tableName = "todos")
data class TodoEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val subjectId: Long = 0,
    val category: String = "Study",
    val deadlineMillis: Long = 0,
    val priority: Int = 1,
    val done: Boolean = false
)


/** Completed focus or break timer record. */
@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAtMillis: Long,
    val durationMinutes: Int,
    val actualSeconds: Int,
    val subjectId: Long = 0,
    val mode: String = "Focus",
    val completed: Boolean = true
)
