package com.examora.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.examora.app.data.planner.ChapterEntity
import com.examora.app.data.planner.FocusSessionEntity
import com.examora.app.data.planner.PlannerDatabase
import com.examora.app.data.planner.PlannerPrefs
import com.examora.app.data.planner.StudySessionEntity
import com.examora.app.data.planner.SubjectEntity
import com.examora.app.data.planner.TodoEntity
import com.examora.app.notify.SessionNotifier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PlannerViewModel(private val app: Application) : AndroidViewModel(app) {
    private val dao = PlannerDatabase.get(app).plannerDao()
    private val prefs = PlannerPrefs(app)

    val subjects: StateFlow<List<SubjectEntity>> =
        dao.observeSubjects().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val chapters: StateFlow<List<ChapterEntity>> =
        dao.observeChapters().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val sessions: StateFlow<List<StudySessionEntity>> =
        dao.observeSessions().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val todos: StateFlow<List<TodoEntity>> =
        dao.observeTodos().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val focusSessions: StateFlow<List<FocusSessionEntity>> =
        dao.observeFocusSessions().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun saveFocusSession(session: FocusSessionEntity) {
        viewModelScope.launch { dao.insertFocusSession(session) }
    }

    private val _goalMinutes = MutableStateFlow(prefs.goalMinutes())
    val dailyGoalMinutes: StateFlow<Int> = _goalMinutes

    init {
        // Make sure every pending session has its reminder queued (safe to repeat).
        viewModelScope.launch {
            SessionNotifier.createChannel(app)
            val allSubjects = dao.observeSubjects().first()
            val allChapters = dao.observeChapters().first()
            dao.observeSessions().first().forEach { session ->
                SessionNotifier.schedule(app, session, labelFor(session, allSubjects, allChapters))
            }
        }
    }

    private fun labelFor(
        session: StudySessionEntity,
        allSubjects: List<SubjectEntity>,
        allChapters: List<ChapterEntity>
    ): String {
        val subject = allSubjects.firstOrNull { it.id == session.subjectId }?.name
        val chapter = allChapters.firstOrNull { it.id == session.chapterId }?.name
        val parts = listOf(session.title, subject ?: "", chapter ?: "").filter { it.isNotBlank() }
        return if (parts.isEmpty()) "Study" else parts.joinToString(" - ")
    }

    fun setGoal(minutes: Int) {
        prefs.setGoalMinutes(minutes)
        _goalMinutes.value = minutes
    }

    fun saveSubject(subject: SubjectEntity) {
        viewModelScope.launch { dao.upsertSubject(subject) }
    }

    fun deleteSubject(subject: SubjectEntity) {
        viewModelScope.launch {
            dao.deleteChaptersOf(subject.id)
            dao.clearSubjectInSessions(subject.id)
            dao.clearSubjectInTodos(subject.id)
            dao.deleteSubject(subject)
        }
    }

    fun saveChapter(chapter: ChapterEntity) {
        viewModelScope.launch { dao.upsertChapter(chapter) }
    }

    fun deleteChapter(chapter: ChapterEntity) {
        viewModelScope.launch {
            dao.clearChapterInSessions(chapter.id)
            dao.deleteChapter(chapter)
        }
    }

    fun saveSession(session: StudySessionEntity) {
        viewModelScope.launch {
            val rowId = dao.upsertSession(session)
            // For a new row Room returns its id; for an update the id is already known.
            val id = if (session.id == 0L) rowId else session.id
            val saved = session.copy(id = id)
            SessionNotifier.schedule(
                app,
                saved,
                labelFor(saved, subjects.value, chapters.value)
            )
        }
    }

    fun toggleSession(session: StudySessionEntity) {
        saveSession(session.copy(done = !session.done))
    }

    fun deleteSession(session: StudySessionEntity) {
        viewModelScope.launch {
            dao.deleteSession(session)
            SessionNotifier.cancel(app, session.id)
        }
    }

    fun saveTodo(todo: TodoEntity) {
        viewModelScope.launch { dao.upsertTodo(todo) }
    }

    fun toggleTodo(todo: TodoEntity) {
        saveTodo(todo.copy(done = !todo.done))
    }

    fun deleteTodo(todo: TodoEntity) {
        viewModelScope.launch { dao.deleteTodo(todo) }
    }
}
