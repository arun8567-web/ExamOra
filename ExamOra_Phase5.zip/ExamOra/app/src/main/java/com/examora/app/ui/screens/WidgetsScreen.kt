package com.examora.app.ui.screens

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamTextSoft
import com.examora.app.widget.ExamWidgetProvider
import com.examora.app.widget.ExamWidgetUpdater
import com.examora.app.widget.WidgetStyle
import com.examora.app.widget.WidgetStyles

@Composable
fun WidgetsScreen() {
    val context = LocalContext.current
    var category by remember { mutableStateOf("Aesthetic") }
    var selectedId by remember { mutableStateOf(WidgetStyles.selected(context).id) }
    val visibleStyles = remember(category) { WidgetStyles.all.filter { it.category == category } }
    val selectedStyle = WidgetStyles.byId(selectedId)

    Column(
        modifier = Modifier.fillMaxSize().background(ExamBg).padding(horizontal = 16.dp)
    ) {
        Text("Widget Gallery", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White,
            modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
        Text("Tumhare reference designs se 180 styles", color = ExamTextSoft, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))

        WidgetPreview(style = selectedStyle, modifier = Modifier.fillMaxWidth())
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Column(Modifier.weight(1f)) {
                Text(selectedStyle.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("${selectedStyle.category} • Style ${selectedStyle.id + 1} / 180", color = ExamTextSoft, fontSize = 12.sp)
            }
            Button(onClick = {
                WidgetStyles.select(context, selectedId)
                ExamWidgetUpdater.refresh(context)
                Toast.makeText(context, "${selectedStyle.name} applied to home-screen widget", Toast.LENGTH_SHORT).show()
            }, colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.size(5.dp))
                Text("Apply")
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            WidgetStyles.categories.forEach { item ->
                FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) })
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("${category} styles  (20)", color = ExamOrange, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(visibleStyles, key = { it.id }) { style ->
                StyleTile(style = style, selected = selectedId == style.id) { selectedId = style.id }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = {
                val manager = AppWidgetManager.getInstance(context)
                if (manager.isRequestPinAppWidgetSupported) {
                    manager.requestPinAppWidget(ComponentName(context, ExamWidgetProvider::class.java), null, null)
                } else {
                    Toast.makeText(context, "Home screen long-press > Widgets > ExamOra", Toast.LENGTH_LONG).show()
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ExamSurface, contentColor = Color.White)
        ) {
            Icon(Icons.Filled.Home, contentDescription = null)
            Spacer(Modifier.size(8.dp))
            Text("Home screen par widget lagao")
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun StyleTile(style: WidgetStyle, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
            .then(if (selected) Modifier.border(2.dp, ExamOrange, RoundedCornerShape(16.dp)) else Modifier),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ExamSurface)
    ) {
        Column(Modifier.padding(8.dp)) {
            WidgetPreview(style, Modifier.fillMaxWidth().aspectRatio(1.72f))
            Spacer(Modifier.height(7.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(style.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (selected) Icon(Icons.Filled.CheckCircle, contentDescription = "Selected", tint = ExamOrange, modifier = Modifier.size(17.dp))
            }
        }
    }
}

@Composable
private fun WidgetPreview(style: WidgetStyle, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(if (style.layout == 4) 26.dp else 18.dp)
    Row(
        modifier = modifier.clip(shape).background(style.backgroundColor).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(0.88f)) {
            Text("EXAM", color = style.accentColor, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text("JEE Main 2027", color = style.textColor, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Row(verticalAlignment = Alignment.Bottom) {
                Text("77", color = style.accentColor, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 30.sp)
                Text(" days left", color = style.mutedColor, fontSize = 9.sp, modifier = Modifier.padding(start = 3.dp, bottom = 4.dp))
            }
            Text("20 Jan 2027", color = style.mutedColor, fontSize = 9.sp)
        }
        if (style.layout % 2 == 1) {
            Box(Modifier.weight(0.12f).height(56.dp).background(style.accentColor.copy(alpha = 0.7f), RoundedCornerShape(8.dp)))
        } else {
            Column(Modifier.weight(0.42f), horizontalAlignment = Alignment.End) {
                Text("QUOTE OF DAY", color = style.accentColor, fontSize = 7.sp, fontWeight = FontWeight.Bold)
                Text("Dreams need focus & consistency.", color = style.textColor, fontSize = 9.sp, lineHeight = 11.sp)
                Text("— ExamOra", color = style.mutedColor, fontSize = 7.sp)
            }
        }
    }
}
