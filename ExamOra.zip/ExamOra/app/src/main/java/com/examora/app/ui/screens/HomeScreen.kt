package com.examora.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.data.ExamStore
import com.examora.app.ui.ExamViewModel
import com.examora.app.ui.components.ExamCard
import com.examora.app.ui.components.ExamDialog
import com.examora.app.ui.components.rememberNow
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamBlue
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamPurple
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamTeal
import com.examora.app.ui.theme.ExamTextSoft
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Locale

private val quotes = listOf(
    "Roz thoda sa padhna, ek din bahut bada result banata hai.",
    "Discipline motivation se zyada der tak chalta hai.",
    "Aaj ka kaam kal pe mat chhodo, kal ka tum thank you bologe.",
    "Consistency > intensity. Har din 1% better.",
    "Mushkil sawal wahi hai jo abhi tak practice nahi kiya.",
    "Exam se pehle ka har ghanta ginti me aata hai.",
    "Gir gaye to kya, revision se wapas uth sakte ho."
)

@Composable
fun HomeScreen(
    vm: ExamViewModel,
    onOpenTab: (String) -> Unit,
    onOpenExams: () -> Unit
) {
    val context = LocalContext.current
    val store = remember { ExamStore(context) }
    val exams by vm.exams.collectAsState()
    val now = rememberNow()
    var showAddDialog by remember { mutableStateOf(false) }
    var quoteIndex by remember { mutableStateOf(store.quoteIndex() % quotes.size) }

    val upcoming = exams.filter { it.timeMillis > now }.sortedBy { it.timeMillis }
    val next = upcoming.firstOrNull()
    val others = upcoming.drop(1).take(3)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Header()

        Text("Next exam", color = ExamTextSoft, fontSize = 13.sp)
        if (next == null) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .background(ExamSurface)
                    .padding(20.dp)
            ) {
                Text("Koi upcoming exam nahi hai", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
                ) { Text("Exam add karo") }
            }
        } else {
            ExamCard(exam = next, now = now)
        }

        if (others.isNotEmpty()) {
            Text("Aur upcoming", fontWeight = FontWeight.SemiBold)
            others.forEach { exam ->
                ExamCard(exam = exam, now = now, compact = true)
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (next != null) {
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
                ) { Text("Add") }
            }
            OutlinedButton(onClick = onOpenExams) { Text("Sab exams manage karo") }
        }

        QuickAccessRow(onOpenTab)

        QuoteCard(
            quote = quotes[quoteIndex],
            onNext = {
                quoteIndex = (quoteIndex + 1) % quotes.size
                store.saveQuoteIndex(quoteIndex)
            }
        )
    }

    if (showAddDialog) {
        ExamDialog(
            initial = null,
            onDismiss = { showAddDialog = false },
            onSave = {
                vm.save(it)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun Header() {
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greeting = when (hour) {
        in 5..11 -> "Good morning"
        in 12..16 -> "Good afternoon"
        in 17..20 -> "Good evening"
        else -> "Good night"
    }
    val date = remember {
        LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()))
    }
    Column {
        Text("ExamOra", color = ExamOrange, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(greeting, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(date, color = ExamTextSoft, fontSize = 14.sp)
        Text("Plan Smart. Study Better. Achieve More.", color = ExamTextSoft, fontSize = 12.sp)
    }
}

@Composable
private fun QuickAccessRow(onOpenTab: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Quick access", fontWeight = FontWeight.SemiBold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickItem("Planner", Icons.Filled.DateRange, ExamBlue, Modifier.weight(1f)) { onOpenTab("planner") }
            QuickItem("Widgets", Icons.Filled.Widgets, ExamPurple, Modifier.weight(1f)) { onOpenTab("widgets") }
            QuickItem("Progress", Icons.Filled.BarChart, ExamTeal, Modifier.weight(1f)) { onOpenTab("progress") }
        }
    }
}

@Composable
private fun QuickItem(
    label: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(ExamSurface)
            .clickable(onClick = onClick)
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, contentDescription = label, tint = tint)
        Text(label, fontSize = 13.sp)
    }
}

@Composable
private fun QuoteCard(quote: String, onNext: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(ExamSurface)
            .padding(20.dp)
    ) {
        Text("Motivation", color = ExamOrange, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(quote, fontSize = 17.sp)
        Spacer(Modifier.height(8.dp))
        TextButton(onClick = onNext) { Text("Next quote", color = ExamOrange) }
    }
}
