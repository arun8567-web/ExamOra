package com.examora.app.widget

import android.content.Context
import androidx.compose.ui.graphics.Color

/** 180 selectable widget presets grouped into the nine visual families supplied by the user. */
data class WidgetStyle(
    val id: Int,
    val category: String,
    val name: String,
    val background: Long,
    val accent: Long,
    val text: Long,
    val muted: Long,
    val layout: Int
) {
    val backgroundColor: Color get() = Color(background)
    val accentColor: Color get() = Color(accent)
    val textColor: Color get() = Color(text)
    val mutedColor: Color get() = Color(muted)
}

object WidgetStyles {
    private data class Family(
        val category: String,
        val names: List<String>,
        val palettes: List<LongArray>
    )

    private val families = listOf(
        Family("Aesthetic", listOf(
            "Minimal Clean", "Pastel Soft", "Sunset View", "Sky & Clouds", "Cherry Blossom",
            "Night Moon", "Vintage Paper", "Aesthetic Notebook", "Minimal Gradient", "Lofi Study",
            "Forest Green", "Aesthetic Floral", "Dawn Landscape", "City Skyline", "Window View",
            "Paper Tape", "Film Frame", "Watercolor", "Minimal Dark", "Skyline Night"
        ), listOf(
            longArrayOf(0xFFFFE9D9,0xFF9B4B35,0xFF2B1D1A,0xFF725B55), longArrayOf(0xFFF7D9E8,0xFFB43B70,0xFF311A2A,0xFF805B70),
            longArrayOf(0xFF2A1C2D,0xFFFFA36C,0xFFFFFFFF,0xFFD8B8C8), longArrayOf(0xFFD9EEFF,0xFF2878B8,0xFF102A43,0xFF45647D),
            longArrayOf(0xFFFFD8E7,0xFFC13F73,0xFF351A2A,0xFF87536C)
        )),
        Family("Nature", listOf(
            "Forest Green", "Mountain View", "Sunrise Hills", "Lake & Mountains", "Waterfall",
            "Riverside", "Plants & Leaves", "Bamboo", "Wild Flowers", "Rainy Window",
            "Forest Path", "Garden Vibes", "Leafy Minimal", "Cloudy Hills", "Stream Rocks",
            "Tree Silhouette", "Green Meadow", "Night Forest", "Lotus Pond", "Nature Stone"
        ), listOf(
            longArrayOf(0xFF102D22,0xFF8DD7A5,0xFFFFFFFF,0xFFB8D1C1), longArrayOf(0xFFDCEEFF,0xFF3977A8,0xFF142D43,0xFF5B758B),
            longArrayOf(0xFFFFE0B5,0xFFBD6B32,0xFF342316,0xFF80664B), longArrayOf(0xFF153D4B,0xFF62D2C7,0xFFFFFFFF,0xFFB6D5D2),
            longArrayOf(0xFFEAF1D9,0xFF588047,0xFF1D321D,0xFF71866A)
        )),
        Family("Glassy", listOf(
            "Classic Frosted Glass", "Transparent Clear Glass", "Blurred Background Glass", "Gradient Glass", "Glass with Border Glow",
            "Glass with Icons", "Glass Card with Floating Elements", "Thin Glass Outline", "Multi-layer Glass", "Glass with Side Image",
            "Glass with Water Droplets", "Glass with Soft Shadows", "Glass with Dark Blur", "Glass with Color Tint", "Holographic Glass",
            "Glass with Notebook Style", "Glass with Gradient Blur", "Glass with Minimal Icons", "Glass with Shape Cut", "Ultra Minimal Glass"
        ), listOf(
            longArrayOf(0xFF34404F,0xFFB8D7FF,0xFFFFFFFF,0xFFD3DFEF), longArrayOf(0xFF20344D,0xFF8EDBFF,0xFFFFFFFF,0xFFB8C9D9),
            longArrayOf(0xFF20212C,0xFFFF8CA8,0xFFFFFFFF,0xFFBFC4D0), longArrayOf(0xFF3D2867,0xFFFF9BE8,0xFFFFFFFF,0xFFD7C4EF),
            longArrayOf(0xFF142B45,0xFF54DFFF,0xFFFFFFFF,0xFFB9D8E8)
        )),
        Family("Tricolor", listOf(
            "Classic Tricolor", "Brush Stroke Style", "India Gate View", "Waving Flag", "Minimal Tricolor",
            "Tiranga Ribbon", "Taj Mahal Theme", "Grunge Paint", "Silhouette Freedom", "Horizontal Wave",
            "Soldier Tribute", "Paper Texture", "Night Monument", "Leaf Tricolor", "Ashoka Chakra Focus",
            "Clean Split Panel", "Artistic Watercolor", "Modern Minimal", "Skyline Silhouette", "Premium Dark Tricolor"
        ), listOf(
            longArrayOf(0xFFFFF1E6,0xFFE66A24,0xFF172B45,0xFF52705F), longArrayOf(0xFFFFE8D2,0xFFFF7B27,0xFF1D3428,0xFF56785B),
            longArrayOf(0xFF19352B,0xFFFFB14A,0xFFFFFFFF,0xFFB8D1C2), longArrayOf(0xFF162A46,0xFFFF8A38,0xFFFFFFFF,0xFFB6C8D8),
            longArrayOf(0xFF101820,0xFFFFA64D,0xFFFFFFFF,0xFFB9C7D3)
        )),
        Family("Study", listOf(
            "Study Desk", "Bookshelf", "Notebook Paper", "Sticky Notes", "Dark Study Mode",
            "Minimal Study", "Progress Dashboard", "Calendar Style", "Blackboard Style", "Stationery Theme",
            "Warm Lamp Study", "White & Pastel", "Digital Clock Style", "To-Do List Style", "Aesthetic Study Room",
            "Glass Study", "Timeline Style", "Subject Vibe", "Minimal Quote Focus", "Exam Mode"
        ), listOf(
            longArrayOf(0xFF261A13,0xFFFFB45C,0xFFFFFFFF,0xFFD8BDA4), longArrayOf(0xFF33251C,0xFFE5B76C,0xFFFFFFFF,0xFFD5C2A7),
            longArrayOf(0xFFF4E8D5,0xFFB54B3B,0xFF2A211B,0xFF78685B), longArrayOf(0xFF15202A,0xFF46D9C3,0xFFFFFFFF,0xFFB8C6D2),
            longArrayOf(0xFF172334,0xFF67B7FF,0xFFFFFFFF,0xFFB6C6D8)
        )),
        Family("Dark", listOf(
            "Classic Dark Red", "Minimal Dark", "Elegant Gold", "Dark Blue Premium", "Black & Red Tech",
            "Aesthetic Monochrome", "Neon Red Outline", "Dark Purple", "Matrix Green", "Cyber Grid",
            "Dark Minimal Split", "Space Theme", "Red Smoke", "Minimal Abstract", "Dark Glassmorphism",
            "Gamer Style", "Night City", "Topography Lines", "Premium Black Gold", "Dashboard Pro"
        ), listOf(
            longArrayOf(0xFF160F13,0xFFFF5364,0xFFFFFFFF,0xFFB8AAB0), longArrayOf(0xFF17191E,0xFFE6E8ED,0xFFFFFFFF,0xFF9CA3AF),
            longArrayOf(0xFF17130D,0xFFE7BE70,0xFFFFF1D2,0xFFB7A27D), longArrayOf(0xFF0C1B32,0xFF65C7FF,0xFFFFFFFF,0xFFAFC8E2),
            longArrayOf(0xFF170D12,0xFFFF344D,0xFFFFFFFF,0xFFBDA6AD)
        )),
        Family("Anime", listOf(
            "Naruto Theme", "One Piece Theme", "Attack on Titan Theme", "Demon Slayer Theme", "Jujutsu Kaisen Theme",
            "My Hero Academia Theme", "Death Note Theme", "Classroom Study Anime", "City Night Anime", "Aesthetic Room Anime",
            "Sky & Clouds Anime", "Rainy Window Anime", "Cherry Blossom Anime", "Shonen Motivation", "Night Moon Panel",
            "Manga Panel Style", "Ghibli Style", "Minimal Anime", "Split Anime Panel", "Neon Cyber Anime"
        ), listOf(
            longArrayOf(0xFF27172B,0xFFFF9C56,0xFFFFFFFF,0xFFD8B6C9), longArrayOf(0xFF172C48,0xFF65C6F5,0xFFFFFFFF,0xFFB4C8E1),
            longArrayOf(0xFF1A1B22,0xFFFF5C65,0xFFFFFFFF,0xFFC0BFC8), longArrayOf(0xFF281A3D,0xFFFF8BC7,0xFFFFFFFF,0xFFC8B6D8),
            longArrayOf(0xFF151B35,0xFF8D9CFF,0xFFFFFFFF,0xFFB9C4E8)
        )),
        Family("Countdown", listOf(
            "Circular Progress", "Flip Clock", "Digital Counter", "Compact Horizontal", "Calendar Style",
            "Ring with Stats", "Hourglass Style", "Progress Bar", "Dotted Circle", "Neumorphic",
            "Timeline Style", "Minimal Circle", "Layered Ring", "Glassmorphism", "Analog Clock",
            "Vertical Split", "Hexagon", "Circle + Calendar", "Number Cards", "3D Hologram"
        ), listOf(
            longArrayOf(0xFF121826,0xFFFF8B62,0xFFFFFFFF,0xFFB9C2D1), longArrayOf(0xFF111318,0xFFFF6F9C,0xFFFFFFFF,0xFFB8BBC5),
            longArrayOf(0xFF071D2A,0xFF3DE7FF,0xFFFFFFFF,0xFF9BC8D4), longArrayOf(0xFF1A202C,0xFFFFB34E,0xFFFFFFFF,0xFFB8C0CE),
            longArrayOf(0xFF1B2030,0xFFB18CFF,0xFFFFFFFF,0xFFC1B8D8)
        )),
        Family("Neon", listOf(
            "Cyberpunk Neon", "Neon Gradient Glow", "HUD Futuristic", "Neon Circle Ring", "Neon Skyline",
            "Dark Neon Minimal", "Neon Sci-Fi Panel", "Neon Particles", "Neon Glassmorphism", "Neon Tech Grid",
            "Neon Corner Accents", "Neon Double Panel", "Neon Analog Clock", "Neon Wave", "Neon Hexagon",
            "Neon Matrix", "Neon Gamer Style", "Neon Minimal Dots", "Neon 3D Glow", "Neon Space"
        ), listOf(
            longArrayOf(0xFF080F25,0xFF36E8FF,0xFFFFFFFF,0xFFA8C7E8), longArrayOf(0xFF1B0C35,0xFFFF55E8,0xFFFFFFFF,0xFFC6B3E5),
            longArrayOf(0xFF071C2D,0xFF31D8FF,0xFFFFFFFF,0xFF9FC8E5), longArrayOf(0xFF100C2B,0xFFBD68FF,0xFFFFFFFF,0xFFC8B1E8),
            longArrayOf(0xFF220C25,0xFFFF4E92,0xFFFFFFFF,0xFFD2A9C7)
        ))
    )

    val categories: List<String> = families.map { it.category }
    val all: List<WidgetStyle> = families.flatMapIndexed { familyIndex, family ->
        family.names.mapIndexed { index, name ->
            val p = family.palettes[index % family.palettes.size]
            val variant = index % 5
            WidgetStyle(familyIndex * 20 + index, family.category, name, p[0], p[1], p[2], p[3], variant)
        }
    }

    fun byId(id: Int): WidgetStyle = all.firstOrNull { it.id == id } ?: all.first()
    fun selected(context: Context): WidgetStyle {
        val id = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_STYLE, 0)
        return byId(id)
    }
    fun select(context: Context, id: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_STYLE, id).apply()
    }
    private const val PREFS = "examora_widget_styles"
    private const val KEY_STYLE = "selected_style_id"
}
