package com.examora.app.util

import java.text.SimpleDateFormat
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.TemporalAdjusters
import java.util.Locale

private fun zone(): ZoneId = ZoneId.systemDefault()

fun todayDate(): LocalDate = LocalDate.now(zone())

fun LocalDate.startMillis(): Long = atStartOfDay(zone()).toInstant().toEpochMilli()

fun Long.toLocalDate(): LocalDate = Instant.ofEpochMilli(this).atZone(zone()).toLocalDate()

fun mondayOf(date: LocalDate): LocalDate =
    date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))

fun minuteOfDay(millis: Long): Int {
    val time = Instant.ofEpochMilli(millis).atZone(zone()).toLocalTime()
    return time.hour * 60 + time.minute
}

/** Start of [date] plus [minuteOfDay] minutes, in epoch millis. */
fun combine(date: LocalDate, minuteOfDay: Int): Long =
    date.startMillis() + minuteOfDay * 60_000L

fun formatMinuteOfDay(minutes: Int): String {
    val h = minutes / 60
    val m = minutes % 60
    val suffix = if (h < 12) "AM" else "PM"
    val h12 = if (h % 12 == 0) 12 else h % 12
    return String.format(Locale.getDefault(), "%02d:%02d %s", h12, m, suffix)
}

fun formatTime(millis: Long): String =
    SimpleDateFormat("hh:mm a", Locale.getDefault()).format(millis)

fun formatDay(millis: Long): String =
    SimpleDateFormat("EEE, d MMM", Locale.getDefault()).format(millis)

fun formatDateTime(millis: Long): String =
    SimpleDateFormat("d MMM, hh:mm a", Locale.getDefault()).format(millis)

fun formatDuration(minutes: Int): String =
    if (minutes >= 60) "${minutes / 60}h ${minutes % 60}m" else "${minutes}m"
