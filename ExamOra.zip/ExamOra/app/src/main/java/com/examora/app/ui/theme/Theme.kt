package com.examora.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ExamBg = Color(0xFF0B0D12)
val ExamSurface = Color(0xFF151923)
val ExamSurfaceHigh = Color(0xFF1D2330)
val ExamOrange = Color(0xFFFF8A32)
val ExamPurple = Color(0xFF9B7BFF)
val ExamBlue = Color(0xFF4DA3FF)
val ExamTeal = Color(0xFF2EC4B6)
val ExamGreen = Color(0xFF5BD68A)
val ExamTextPrimary = Color(0xFFFFFFFF)
val ExamTextSoft = Color(0xFFA6ADBB)

private val DarkScheme = darkColorScheme(
    primary = ExamOrange,
    onPrimary = Color(0xFF1A0E00),
    secondary = ExamPurple,
    tertiary = ExamTeal,
    background = ExamBg,
    onBackground = ExamTextPrimary,
    surface = ExamSurface,
    onSurface = ExamTextPrimary,
    surfaceVariant = ExamSurfaceHigh,
    onSurfaceVariant = ExamTextSoft
)

@Composable
fun ExamOraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkScheme, content = content)
}
