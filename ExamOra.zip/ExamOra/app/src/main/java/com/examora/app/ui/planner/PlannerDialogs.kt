package com.examora.app.ui.planner

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.examora.app.data.planner.ChapterEntity
import com.examora.app.data.planner.StudySessionEntity
import com.examora.app.data.planner.SubjectEntity
import com.examora.app.data.planner.TodoEntity
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamRed
import com.examora.app.ui.theme.ExamTextSoft
import com.examora.app.util.combine
import com.examora.app.util.formatDay
import com.examora.app.util.formatMinuteOfDay
import com.examora.app.util.minuteOfDay
import com.examora.app.util.toLocalDate
import java.time.LocalDate

/** Small dialog with one text field (also used for the numeric daily goal). */
@Composable
fun NameDialog(
    title: String,
    label: String,
    initial: String,
    numeric: Boolean = false,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(label) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(
                    keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text
                )
            )
        },
        confirmButton = {
            TextButton(enabled = text.isNotBlank(), onClick = { onSave(text.trim()) }) {
                Text("Save", color = ExamOrange)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ColorDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(color)
            .then(if (selected) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
            .clickable(onClick = onClick)
    )
}

@Composable
fun SubjectDialog(
    initial: SubjectEntity?,
    onDismiss: () -> Unit,
    onSave: (SubjectEntity) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var colorIndex by remember { mutableIntStateOf(initial?.colorIndex ?: 0) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Subject add karo" else "Subject edit karo") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Subject (e.g. Physics)") },
                    singleLine = true
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    subjectColors.forEachIndexed { index, color ->
                        ColorDot(color, selected = index == colorIndex) { colorIndex = index }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(SubjectEntity(id = initial?.id ?: 0L, name = name.trim(), colorIndex = colorIndex))
                }
            ) { Text("Save", color = ExamOrange) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SessionDialog(
    initial: StudySessionEntity?,
    defaultDate: LocalDate,
    subjects: List<SubjectEntity>,
    chapters: List<ChapterEntity>,
    onDismiss: () -> Unit,
    onSave: (StudySessionEntity) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var subjectId by remember { mutableLongStateOf(initial?.subjectId ?: 0L) }
    var chapterId by remember { mutableLongStateOf(initial?.chapterId ?: 0L) }
    var date by remember { mutableStateOf(initial?.startMillis?.toLocalDate() ?: defaultDate) }
    var startMin by remember { mutableIntStateOf(initial?.let { minuteOfDay(it.startMillis) } ?: (18 * 60)) }
    var endMin by remember { mutableIntStateOf(initial?.let { minuteOfDay(it.endMillis) } ?: (19 * 60)) }
    var priority by remember { mutableIntStateOf(initial?.priority ?: 1) }

    val subjectChapters = chapters.filter { subjectId != 0L && it.subjectId == subjectId }
    val timeOk = endMin > startMin

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Study session add karo" else "Session edit / reschedule") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Topic / note (optional)") },
                    singleLine = true
                )

                Text("Subject", color = ExamTextSoft)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = subjectId == 0L,
                        onClick = {
                            subjectId = 0L
                            chapterId = 0L
                        },
                        label = { Text("None") }
                    )
                    subjects.forEach { s ->
                        FilterChip(
                            selected = subjectId == s.id,
                            onClick = {
                                subjectId = s.id
                                chapterId = 0L
                            },
                            label = { Text(s.name) }
                        )
                    }
                }
                if (subjects.isEmpty()) {
                    Text("Subjects tab me pehle subject add kar sakte ho.", color = ExamTextSoft)
                }

                if (subjectChapters.isNotEmpty()) {
                    Text("Chapter", color = ExamTextSoft)
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = chapterId == 0L,
                            onClick = { chapterId = 0L },
                            label = { Text("None") }
                        )
                        subjectChapters.forEach { c ->
                            FilterChip(
                                selected = chapterId == c.id,
                                onClick = { chapterId = c.id },
                                label = { Text(c.name) }
                            )
                        }
                    }
                }

                Text("Date", color = ExamTextSoft)
                OutlinedButton(onClick = { pickDate(context, date) { date = it } }) {
                    Text(formatDay(combine(date, 0)))
                }

                Text("Start / End time", color = ExamTextSoft)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        pickTime(context, startMin) { picked ->
                            startMin = picked
                            if (endMin <= picked) endMin = minOf(picked + 60, 23 * 60 + 59)
                        }
                    }) { Text(formatMinuteOfDay(startMin)) }
                    OutlinedButton(onClick = {
                        pickTime(context, endMin) { picked -> endMin = picked }
                    }) { Text(formatMinuteOfDay(endMin)) }
                }
                if (!timeOk) {
                    Text("End time start ke baad ka hona chahiye.", color = ExamRed)
                }

                Text("Priority", color = ExamTextSoft)
                PriorityPicker(priority) { priority = it }
            }
        },
        confirmButton = {
            TextButton(
                enabled = timeOk && (title.isNotBlank() || subjectId != 0L),
                onClick = {
                    onSave(
                        StudySessionEntity(
                            id = initial?.id ?: 0L,
                            title = title.trim(),
                            subjectId = subjectId,
                            chapterId = chapterId,
                            startMillis = combine(date, startMin),
                            endMillis = combine(date, endMin),
                            priority = priority,
                            done = initial?.done ?: false
                        )
                    )
                }
            ) { Text("Save", color = ExamOrange) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun TodoDialog(
    initial: TodoEntity?,
    defaultDate: LocalDate,
    subjects: List<SubjectEntity>,
    onDismiss: () -> Unit,
    onSave: (TodoEntity) -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf(initial?.title ?: "") }
    var subjectId by remember { mutableLongStateOf(initial?.subjectId ?: 0L) }
    var category by remember { mutableStateOf(initial?.category ?: todoCategories[0]) }
    var priority by remember { mutableIntStateOf(initial?.priority ?: 1) }
    var hasDeadline by remember {
        mutableStateOf(if (initial == null) true else initial.deadlineMillis != 0L)
    }
    var date by remember {
        mutableStateOf(
            if (initial != null && initial.deadlineMillis != 0L) {
                initial.deadlineMillis.toLocalDate()
            } else {
                defaultDate
            }
        )
    }
    var minute by remember {
        mutableIntStateOf(
            if (initial != null && initial.deadlineMillis != 0L) {
                minuteOfDay(initial.deadlineMillis)
            } else {
                21 * 60
            }
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Task add karo" else "Task edit karo") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task") },
                    singleLine = true
                )

                Text("Category", color = ExamTextSoft)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    todoCategories.forEach { c ->
                        FilterChip(
                            selected = category == c,
                            onClick = { category = c },
                            label = { Text(c) }
                        )
                    }
                }

                Text("Subject", color = ExamTextSoft)
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = subjectId == 0L,
                        onClick = { subjectId = 0L },
                        label = { Text("None") }
                    )
                    subjects.forEach { s ->
                        FilterChip(
                            selected = subjectId == s.id,
                            onClick = { subjectId = s.id },
                            label = { Text(s.name) }
                        )
                    }
                }

                Text("Priority", color = ExamTextSoft)
                PriorityPicker(priority) { priority = it }

                FilterChip(
                    selected = hasDeadline,
                    onClick = { hasDeadline = !hasDeadline },
                    label = { Text(if (hasDeadline) "Deadline: ON" else "Deadline: OFF") }
                )
                if (hasDeadline) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { pickDate(context, date) { date = it } }) {
                            Text(formatDay(combine(date, 0)))
                        }
                        OutlinedButton(onClick = { pickTime(context, minute) { minute = it } }) {
                            Text(formatMinuteOfDay(minute))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = title.isNotBlank(),
                onClick = {
                    onSave(
                        TodoEntity(
                            id = initial?.id ?: 0L,
                            title = title.trim(),
                            subjectId = subjectId,
                            category = category,
                            deadlineMillis = if (hasDeadline) combine(date, minute) else 0L,
                            priority = priority,
                            done = initial?.done ?: false
                        )
                    )
                }
            ) { Text("Save", color = ExamOrange) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
