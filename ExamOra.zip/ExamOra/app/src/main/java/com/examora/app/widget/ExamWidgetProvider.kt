package com.examora.app.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

class ExamWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        ExamWidgetUpdater.refresh(context)
    }

    override fun onEnabled(context: Context) {
        ExamWidgetUpdater.refresh(context)
    }

    override fun onDisabled(context: Context) {
        ExamWidgetUpdater.cancel(context)
    }
}
