package com.examora.app.ui.screens

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamTextSoft
import com.examora.app.widget.ExamWidgetProvider
import com.examora.app.widget.ExamWidgetUpdater
import com.examora.app.widget.WidgetStyle
import com.examora.app.widget.WidgetStyles

@Composable
fun WidgetsScreen() {
    val context = LocalContext.current
    var category by remember { mutableStateOf("All") }
    var query by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf(WidgetStyles.selected(context).id) }
    var favorites by remember { mutableStateOf(WidgetStyles.favorites(context)) }
    val selectedStyle = WidgetStyles.byId(selectedId)
    val categories = listOf("All", "Favorites") + WidgetStyles.categories
    val visibleStyles = remember(category, query, favorites) {
        WidgetStyles.all.filter { style ->
            val categoryMatch = when (category) {
                "All" -> true
                "Favorites" -> favorites.contains(style.id)
                else -> style.category == category
            }
            categoryMatch && (query.isBlank() || style.name.contains(query, true) || style.category.contains(query, true))
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(ExamBg).padding(horizontal = 16.dp)) {
        Text("Widget Gallery", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White,
            modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
        Text("180 designs • 9 categories • Live countdown", color = ExamTextSoft, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))

        WidgetPreview(selectedStyle, Modifier.fillMaxWidth().height(150.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Column(Modifier.weight(1f)) {
                Text(selectedStyle.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("${selectedStyle.category} • ${selectedStyle.id + 1} / 180", color = ExamTextSoft, fontSize = 12.sp)
            }
            IconButton(onClick = {
                WidgetStyles.toggleFavorite(context, selectedId)
                favorites = WidgetStyles.favorites(context)
            }) {
                Icon(if (favorites.contains(selectedId)) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorite", tint = ExamOrange)
            }
            Button(onClick = {
                WidgetStyles.select(context, selectedId)
                ExamWidgetUpdater.refresh(context)
                Toast.makeText(context, "${selectedStyle.name} applied to home-screen widget", Toast.LENGTH_SHORT).show()
            }, colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.size(5.dp))
                Text("Apply")
            }
        }

        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Search designs or categories", color = ExamTextSoft) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = ExamTextSoft) },
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = ExamOrange, unfocusedBorderColor = ExamSurface,
                cursorColor = ExamOrange
            )
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            categories.forEach { item ->
                FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("${visibleStyles.size} designs", color = ExamOrange, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        if (visibleStyles.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No designs found. Search another name.", color = ExamTextSoft)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2), modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(visibleStyles, key = { it.id }) { style ->
                    StyleTile(style, selectedId == style.id, favorites.contains(style.id)) {
                        selectedId = style.id
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            val manager = AppWidgetManager.getInstance(context)
            if (manager.isRequestPinAppWidgetSupported) {
                manager.requestPinAppWidget(ComponentName(context, ExamWidgetProvider::class.java), null, null)
            } else {
                Toast.makeText(context, "Home screen long-press > Widgets > ExamOra", Toast.LENGTH_LONG).show()
            }
        }, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ExamSurface, contentColor = Color.White)) {
            Icon(Icons.Filled.Home, contentDescription = null)
            Spacer(Modifier.size(8.dp))
            Text("Home screen par widget lagao")
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun StyleTile(style: WidgetStyle, selected: Boolean, favorite: Boolean, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
        .then(if (selected) Modifier.border(2.dp, ExamOrange, RoundedCornerShape(16.dp)) else Modifier),
        shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = ExamSurface)) {
        Column(Modifier.padding(8.dp)) {
            Box {
                WidgetPreview(style, Modifier.fillMaxWidth().aspectRatio(1.72f))
                if (favorite) Icon(Icons.Filled.Favorite, contentDescription = "Favorite", tint = ExamOrange,
                    modifier = Modifier.align(Alignment.TopEnd).padding(7.dp).size(16.dp))
            }
            Spacer(Modifier.height(7.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(style.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (selected) Icon(Icons.Filled.CheckCircle, contentDescription = "Selected", tint = ExamOrange, modifier = Modifier.size(17.dp))
            }
        }
    }
}

@Composable
private fun WidgetPreview(style: WidgetStyle, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(if (style.category == "Glassy" || style.category == "Neon") 24.dp else 18.dp)
    Row(modifier = modifier.clip(shape).background(style.backgroundColor).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(0.95f)) {
            Text(if (style.category == "Tricolor") "🇮🇳 EXAM" else "EXAMORA • ${style.category.uppercase()}",
                color = style.accentColor, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
            Text("JEE Main 2027", color = style.textColor, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Row(verticalAlignment = Alignment.Bottom) {
                Text("77", color = style.accentColor, fontSize = if (style.layout % 4 == 1) 34.sp else 29.sp,
                    fontWeight = FontWeight.ExtraBold, lineHeight = 32.sp)
                Text(" days left", color = style.mutedColor, fontSize = 9.sp, modifier = Modifier.padding(start = 3.dp, bottom = 4.dp))
            }
            Text("20 Jan 2027  •  09:00 AM", color = style.mutedColor, fontSize = 8.sp)
        }
        Box(Modifier.weight(0.58f).height(74.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val c = style.accentColor.copy(alpha = 0.65f)
                when (style.category) {
                    "Nature" -> {
                        drawCircle(c, size.minDimension * .23f, Offset(size.width * .72f, size.height * .28f))
                        drawLine(c, Offset(size.width * .25f, size.height * .82f), Offset(size.width * .65f, size.height * .30f), 5f)
                        drawLine(c, Offset(size.width * .48f, size.height * .82f), Offset(size.width * .82f, size.height * .48f), 5f)
                    }
                    "Tricolor" -> {
                        drawRect(Color(0xFFFF9933).copy(alpha = .7f), Offset(size.width*.12f,size.height*.25f), Size(size.width*.78f,size.height*.16f))
                        drawRect(Color.White.copy(alpha = .8f), Offset(size.width*.12f,size.height*.42f), Size(size.width*.78f,size.height*.16f))
                        drawRect(Color(0xFF138808).copy(alpha = .8f), Offset(size.width*.12f,size.height*.59f), Size(size.width*.78f,size.height*.16f))
                    }
                    "Study" -> {
                        for (i in 1..4) drawLine(c, Offset(size.width*.12f, size.height*(i*.18f)), Offset(size.width*.9f, size.height*(i*.18f)), 2f)
                        drawCircle(c, size.minDimension*.14f, Offset(size.width*.76f,size.height*.23f))
                    }
                    "Countdown" -> drawArc(c, -90f, 285f, false, Offset(size.width*.15f,size.height*.02f), Size(size.height*.94f,size.height*.94f), style = Stroke(width = 7f))
                    "Glassy" -> {
                        drawRoundRect(c.copy(alpha=.22f), Offset(size.width*.08f,size.height*.08f), Size(size.width*.84f,size.height*.84f))
                        drawRoundRect(c, Offset(size.width*.08f,size.height*.08f), Size(size.width*.84f,size.height*.84f), style = Stroke(width=2f))
                    }
                    "Dark", "Neon" -> {
                        for (i in 0..4) drawLine(c.copy(alpha=.45f), Offset(size.width*(.18f+i*.16f),0f), Offset(size.width*(.18f+i*.16f),size.height), 1.5f)
                        drawRoundRect(c, Offset(2f,2f), Size(size.width-4f,size.height-4f), style=Stroke(width=2f))
                    }
                    "Anime" -> {
                        drawCircle(c, size.minDimension*.25f, Offset(size.width*.72f,size.height*.28f))
                        for (i in 0..8) drawCircle(c.copy(alpha=.5f), 2f+(i%3), Offset(size.width*(.1f+i*.1f),size.height*(.18f+(i%4)*.2f)))
                    }
                    else -> for (i in 0..5) drawCircle(c.copy(alpha=.48f), 4f+(i%3)*4f, Offset(size.width*(.2f+(i%3)*.28f),size.height*(.2f+(i/3)*.48f)))
                }
            }
        }
    }
}
