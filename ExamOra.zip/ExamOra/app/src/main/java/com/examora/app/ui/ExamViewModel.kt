package com.examora.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.examora.app.data.AppDatabase
import com.examora.app.data.ExamEntity
import com.examora.app.data.ExamStore
import com.examora.app.notify.ExamNotifier
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ExamViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).examDao()
    private val legacy = ExamStore(app)

    val exams: StateFlow<List<ExamEntity>> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        viewModelScope.launch {
            migrateLegacyExam()
            ExamNotifier.createChannel(getApplication<Application>())
            ExamNotifier.rescheduleAll(getApplication<Application>(), dao.getAll())
        }
    }

    /** Phase 1 stored one exam in SharedPreferences; move it into the database once. */
    private suspend fun migrateLegacyExam() {
        val old = legacy.load() ?: return
        dao.insert(
            ExamEntity(
                name = old.name,
                timeMillis = old.timeMillis,
                sortOrder = dao.maxOrder() + 1
            )
        )
        legacy.clear()
    }

    fun save(exam: ExamEntity) {
        viewModelScope.launch {
            val id = if (exam.id == 0L) {
                dao.insert(exam.copy(sortOrder = dao.maxOrder() + 1))
            } else {
                dao.update(exam)
                exam.id
            }
            ExamNotifier.schedule(getApplication<Application>(), exam.copy(id = id))
        }
    }

    fun delete(exam: ExamEntity) {
        viewModelScope.launch {
            dao.delete(exam)
            ExamNotifier.cancel(getApplication<Application>(), exam.id)
        }
    }

    /** Swaps the display order of two exams. */
    fun swapOrder(a: ExamEntity, b: ExamEntity) {
        viewModelScope.launch {
            dao.updateAll(listOf(a.copy(sortOrder = b.sortOrder), b.copy(sortOrder = a.sortOrder)))
        }
    }
}
