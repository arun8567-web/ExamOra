package com.examora.app.data

import android.content.Context

/** Single saved exam countdown (Phase 1). Multiple exams + Room come in Phase 2. */
data class Exam(val name: String, val timeMillis: Long)

class ExamStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("examora_prefs", Context.MODE_PRIVATE)

    fun load(): Exam? {
        val name = prefs.getString(KEY_NAME, null) ?: return null
        val time = prefs.getLong(KEY_TIME, -1L)
        if (time < 0) return null
        return Exam(name, time)
    }

    fun save(exam: Exam) {
        prefs.edit().putString(KEY_NAME, exam.name).putLong(KEY_TIME, exam.timeMillis).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY_NAME).remove(KEY_TIME).apply()
    }

    fun quoteIndex(): Int = prefs.getInt(KEY_QUOTE, 0)

    fun saveQuoteIndex(i: Int) {
        prefs.edit().putInt(KEY_QUOTE, i).apply()
    }

    private companion object {
        const val KEY_NAME = "exam_name"
        const val KEY_TIME = "exam_time"
        const val KEY_QUOTE = "quote_index"
    }
}
