package com.examora.app.ui.screens

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamTextSoft
import com.examora.app.widget.ExamWidgetProvider

/** Phase-7 preview: one real home-screen widget. The 160-design gallery is not built yet. */
@Composable
fun WidgetsScreen() {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Widgets", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = ExamOrange)
        Spacer(Modifier.height(12.dp))
        Text(
            "Abhi 1 working widget hai: next exam ka countdown (days + live timer).",
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "160 designs ki gallery abhi nahi bani, wo baad ke phase me aayegi.",
            color = ExamTextSoft,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                val manager = AppWidgetManager.getInstance(context)
                if (manager.isRequestPinAppWidgetSupported) {
                    manager.requestPinAppWidget(
                        ComponentName(context, ExamWidgetProvider::class.java),
                        null,
                        null
                    )
                } else {
                    Toast.makeText(
                        context,
                        "Launcher ye support nahi karta. Home screen long-press > Widgets > ExamOra",
                        Toast.LENGTH_LONG
                    ).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
        ) { Text("Home screen par widget lagao") }
        Spacer(Modifier.height(12.dp))
        Text(
            "Ya home screen par khali jagah long-press karo, Widgets me ExamOra dhundo.",
            color = ExamTextSoft,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )
    }
}
