package com.examora.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ExamDao {
    @Query("SELECT * FROM exams ORDER BY sortOrder ASC, id ASC")
    fun observeAll(): Flow<List<ExamEntity>>

    @Query("SELECT * FROM exams")
    suspend fun getAll(): List<ExamEntity>

    @Query("SELECT COALESCE(MAX(sortOrder), 0) FROM exams")
    suspend fun maxOrder(): Long

    @Insert
    suspend fun insert(exam: ExamEntity): Long

    @Update
    suspend fun update(exam: ExamEntity)

    @Update
    suspend fun updateAll(exams: List<ExamEntity>)

    @Delete
    suspend fun delete(exam: ExamEntity)
}
