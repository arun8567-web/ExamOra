package com.examora.app.ui.planner

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.examora.app.R
import com.examora.app.data.planner.FocusSessionEntity
import com.examora.app.ui.PlannerViewModel
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamGreen
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamPurple
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamSurfaceHigh
import com.examora.app.ui.theme.ExamTextSoft
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val FOCUS_CHANNEL = "focus_timer"

private fun showFocusDone(context: Context, mode: String) {
    val manager = context.getSystemService(NotificationManager::class.java)
    if (Build.VERSION.SDK_INT >= 26) {
        manager.createNotificationChannel(
            NotificationChannel(
                FOCUS_CHANNEL,
                "Focus timer",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "Focus and break timer completion" }
        )
    }
    val notification = NotificationCompat.Builder(context, FOCUS_CHANNEL)
        .setSmallIcon(R.drawable.ic_stat_examora)
        .setContentTitle(if (mode == "Focus") "Focus session complete" else "$mode complete")
        .setContentText(if (mode == "Focus") "Well done! Take a short break." else "Break complete. Ready to focus?")
        .setAutoCancel(true)
        .build()
    try {
        NotificationManagerCompat.from(context).notify(2207, notification)
    } catch (_: SecurityException) {
        // The timer still completes in-app when notification permission is unavailable.
    }
}

private fun clockText(seconds: Int): String {
    val safe = seconds.coerceAtLeast(0)
    return "%02d:%02d".format(safe / 60, safe % 60)
}

@Composable
fun FocusTab(vm: PlannerViewModel) {
    val context = LocalContext.current
    val subjects by vm.subjects.collectAsState()
    val history by vm.focusSessions.collectAsState()

    var mode by remember { mutableStateOf("Focus") }
    var focusMinutes by remember { mutableIntStateOf(25) }
    var remaining by remember { mutableIntStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }
    var selectedSubject by remember { mutableLongStateOf(0L) }
    var startedAt by remember { mutableLongStateOf(0L) }
    var showCustom by remember { mutableStateOf(false) }
    var customValue by remember { mutableStateOf("25") }

    val totalSeconds = when (mode) {
        "Short break" -> 5 * 60
        "Long break" -> 15 * 60
        else -> focusMinutes * 60
    }

    LaunchedEffect(running) {
        while (running && remaining > 0) {
            delay(1000)
            remaining = (remaining - 1).coerceAtLeast(0)
        }
        if (running && remaining == 0) {
            running = false
            val actual = totalSeconds
            vm.saveFocusSession(
                FocusSessionEntity(
                    startedAtMillis = if (startedAt == 0L) System.currentTimeMillis() - actual * 1000L else startedAt,
                    durationMinutes = totalSeconds / 60,
                    actualSeconds = actual,
                    subjectId = if (mode == "Focus") selectedSubject else 0L,
                    mode = mode,
                    completed = true
                )
            )
            showFocusDone(context, mode)
        }
    }

    fun selectMode(next: String) {
        running = false
        mode = next
        remaining = when (next) {
            "Short break" -> 5 * 60
            "Long break" -> 15 * 60
            else -> focusMinutes * 60
        }
        startedAt = 0L
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Focus Timer", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Focus", "Short break", "Long break").forEach { option ->
                FilterChip(
                    selected = mode == option,
                    onClick = { selectMode(option) },
                    label = { Text(option, maxLines = 1) }
                )
            }
        }

        Box(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp))
                .background(ExamSurface).padding(vertical = 26.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(mode, color = ExamOrange, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(10.dp))
                Text(
                    clockText(remaining),
                    fontSize = 58.sp,
                    fontWeight = FontWeight.Bold,
                    color = ExamOrange
                )
                Text(
                    if (running) "Stay focused. One step at a time." else "Ready when you are.",
                    color = ExamTextSoft
                )
                Spacer(Modifier.height(18.dp))
                LinearProgressIndicator(
                    progress = { if (totalSeconds <= 0) 0f else 1f - remaining.toFloat() / totalSeconds },
                    modifier = Modifier.fillMaxWidth(0.78f).height(8.dp).clip(CircleShape),
                    color = ExamOrange,
                    trackColor = ExamSurfaceHigh
                )
            }
        }

        if (mode == "Focus") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Duration: $focusMinutes min", modifier = Modifier.weight(1f), color = ExamTextSoft)
                TextButton(onClick = { customValue = focusMinutes.toString(); showCustom = true }, enabled = !running) {
                    Text("Custom", color = ExamOrange)
                }
            }
            Text("Subject", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                FilterChip(
                    selected = selectedSubject == 0L,
                    onClick = { selectedSubject = 0L },
                    label = { Text("None") },
                    enabled = !running
                )
                subjects.take(3).forEach { subject ->
                    FilterChip(
                        selected = selectedSubject == subject.id,
                        onClick = { selectedSubject = subject.id },
                        label = { Text(subject.name, maxLines = 1) },
                        enabled = !running
                    )
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = {
                    if (!running) {
                        if (startedAt == 0L) startedAt = System.currentTimeMillis()
                        running = true
                    } else running = false
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
            ) { Text(if (running) "Pause" else if (remaining < totalSeconds) "Resume" else "Start") }
            OutlinedButton(
                onClick = {
                    running = false
                    remaining = totalSeconds
                    startedAt = 0L
                },
                modifier = Modifier.weight(1f)
            ) { Text("Reset") }
        }

        val todayStart = java.time.LocalDate.now().atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
        val todayRecords = history.filter { it.startedAtMillis >= todayStart && it.mode == "Focus" }
        val todayMinutes = todayRecords.sumOf { it.actualSeconds } / 60
        Row(
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                .background(ExamSurface).padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text("Today focus", color = ExamTextSoft, fontSize = 12.sp)
                Text("$todayMinutes min", fontWeight = FontWeight.Bold, color = ExamGreen, fontSize = 20.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text("Completed sessions", color = ExamTextSoft, fontSize = 12.sp)
                Text("${todayRecords.size}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
        }

        Text("Recent focus history", fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        if (history.isEmpty()) {
            Text("Abhi koi completed timer nahi hai.", color = ExamTextSoft)
        } else {
            history.take(5).forEach { record ->
                val subjectName = subjects.firstOrNull { it.id == record.subjectId }?.name
                Row(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(ExamSurface).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            if (subjectName.isNullOrBlank()) record.mode else "${record.mode} • $subjectName",
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(record.startedAtMillis)),
                            color = ExamTextSoft,
                            fontSize = 12.sp
                        )
                    }
                    Text("${record.actualSeconds / 60} min", color = ExamGreen)
                }
            }
        }
    }

    if (showCustom) {
        AlertDialog(
            onDismissRequest = { showCustom = false },
            title = { Text("Custom focus duration") },
            text = {
                OutlinedTextField(
                    value = customValue,
                    onValueChange = { customValue = it.filter(Char::isDigit).take(3) },
                    label = { Text("Minutes (1–180)") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val value = customValue.toIntOrNull()
                    if (value != null && value in 1..180) {
                        focusMinutes = value
                        remaining = value * 60
                        startedAt = 0L
                    }
                    showCustom = false
                }) { Text("Save", color = ExamOrange) }
            },
            dismissButton = {
                TextButton(onClick = { showCustom = false }) { Text("Cancel") }
            }
        )
    }
}
