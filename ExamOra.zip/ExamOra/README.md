# ExamOra (Phase 1)

Plan Smart. Study Better. Achieve More.

## Abhi kya kaam karta hai
- Dark premium theme, launcher icon (open book + orange orbit), splash screen
- Bottom navigation: Home, Planner, Widgets, Progress, Settings
- Home: greeting, aaj ki date, exam countdown (days/hours/min/sec live), exam add/edit/delete (save hota hai), motivation quote

## Abhi kya NAHI bana
Planner, To-Do, Focus timer, Reminders, Progress analytics, 160 widgets, Settings.
Ye screens "Abhi built nahi hai" dikhati hain. Ye aage ke phases me aayenge.

## Phone se APK banane ke steps
1. GitHub pe repo me `ExamOra.zip` upload karo (Add file -> Upload files). Zip ko extract MAT karo.
2. Repo me Add file -> Create new file, naam me ye likho: `.github/workflows/build.yml`
   (slash type karte hi folder ban jata hai) aur build.yml ka content paste karo. Commit karo.
3. Actions tab kholo -> "Build ExamOra APK" -> run complete hone do (5-10 min).
4. Run kholo, neeche Artifacts me `ExamOra-debug-apk` download karo, zip extract karke APK install karo.

Note: Ye code abhi tak kisi Android device ya build me test nahi hua. Pehla build fail ho sakta hai, tab error ka screenshot bhejna.
