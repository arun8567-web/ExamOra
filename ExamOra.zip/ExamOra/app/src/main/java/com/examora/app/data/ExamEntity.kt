package com.examora.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One countdown: an exam (with attempt number) or a custom event. */
@Entity(tableName = "exams")
data class ExamEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val timeMillis: Long,
    val isEvent: Boolean = false,
    val attempt: Int = 1,
    val themeIndex: Int = 0,
    val sortOrder: Long = 0
)
