package com.examora.app.ui.planner

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.data.planner.StudySessionEntity
import com.examora.app.ui.theme.ExamBlue
import com.examora.app.ui.theme.ExamGreen
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamPurple
import com.examora.app.ui.theme.ExamRed
import com.examora.app.ui.theme.ExamTeal
import java.time.LocalDate

const val DAY_MS = 24L * 60 * 60 * 1000

/** Length of a session in minutes (kept out of the Room entity on purpose). */
val StudySessionEntity.minutes: Int
    get() = ((endMillis - startMillis) / 60_000L).toInt()

val priorityLabels = listOf("Low", "Medium", "High")

fun priorityLabel(priority: Int): String = priorityLabels[priority.coerceIn(0, 2)]

fun priorityColor(priority: Int): Color = when (priority) {
    0 -> ExamTeal
    1 -> ExamBlue
    else -> ExamRed
}

val subjectColors = listOf(ExamOrange, ExamPurple, ExamBlue, ExamTeal, ExamGreen, ExamRed)

fun subjectColor(index: Int): Color = subjectColors[index.coerceIn(0, subjectColors.lastIndex)]

val todoCategories = listOf("Study", "Revision", "Test", "Homework", "Other")

@Composable
fun SectionHeader(text: String) {
    Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = ExamOrange)
}

@Composable
fun PriorityPicker(selected: Int, onSelect: (Int) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        priorityLabels.forEachIndexed { index, label ->
            FilterChip(
                selected = selected == index,
                onClick = { onSelect(index) },
                label = { Text(label) }
            )
        }
    }
}

@Composable
fun ConfirmDeleteDialog(what: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Delete karna hai?") },
        text = { Text("\"$what\" hata diya jayega.") },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text("Delete", color = ExamOrange) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

fun pickDate(context: Context, current: LocalDate, onPicked: (LocalDate) -> Unit) {
    DatePickerDialog(
        context,
        { _, year, month, day -> onPicked(LocalDate.of(year, month + 1, day)) },
        current.year,
        current.monthValue - 1,
        current.dayOfMonth
    ).show()
}

fun pickTime(context: Context, currentMinute: Int, onPicked: (Int) -> Unit) {
    TimePickerDialog(
        context,
        { _, hour, minute -> onPicked(hour * 60 + minute) },
        currentMinute / 60,
        currentMinute % 60,
        false
    ).show()
}
