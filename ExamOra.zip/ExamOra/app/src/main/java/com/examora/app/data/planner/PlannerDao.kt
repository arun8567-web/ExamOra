package com.examora.app.data.planner

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface PlannerDao {
    @Query("SELECT * FROM subjects ORDER BY id ASC")
    fun observeSubjects(): Flow<List<SubjectEntity>>

    @Query("SELECT * FROM chapters ORDER BY id ASC")
    fun observeChapters(): Flow<List<ChapterEntity>>

    @Query("SELECT * FROM sessions ORDER BY startMillis ASC")
    fun observeSessions(): Flow<List<StudySessionEntity>>

    @Query("SELECT * FROM todos ORDER BY id ASC")
    fun observeTodos(): Flow<List<TodoEntity>>

    @Upsert
    suspend fun upsertSubject(subject: SubjectEntity): Long

    @Upsert
    suspend fun upsertChapter(chapter: ChapterEntity): Long

    @Upsert
    suspend fun upsertSession(session: StudySessionEntity): Long

    @Upsert
    suspend fun upsertTodo(todo: TodoEntity): Long

    @Delete
    suspend fun deleteSubject(subject: SubjectEntity)

    @Delete
    suspend fun deleteChapter(chapter: ChapterEntity)

    @Delete
    suspend fun deleteSession(session: StudySessionEntity)

    @Delete
    suspend fun deleteTodo(todo: TodoEntity)

    @Query("DELETE FROM chapters WHERE subjectId = :subjectId")
    suspend fun deleteChaptersOf(subjectId: Long)

    @Query("UPDATE sessions SET subjectId = 0, chapterId = 0 WHERE subjectId = :subjectId")
    suspend fun clearSubjectInSessions(subjectId: Long)

    @Query("UPDATE todos SET subjectId = 0 WHERE subjectId = :subjectId")
    suspend fun clearSubjectInTodos(subjectId: Long)

    @Query("UPDATE sessions SET chapterId = 0 WHERE chapterId = :chapterId")
    suspend fun clearChapterInSessions(chapterId: Long)
}
