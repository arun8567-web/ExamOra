package com.examora.app.ui.planner

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.data.planner.StudySessionEntity
import com.examora.app.data.planner.TodoEntity
import com.examora.app.ui.PlannerViewModel
import com.examora.app.ui.components.rememberNow
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamPurple
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamTeal
import com.examora.app.ui.theme.ExamTextSoft
import com.examora.app.util.formatDay
import com.examora.app.util.startMillis
import com.examora.app.util.toLocalDate
import com.examora.app.util.todayDate
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

@Composable
private fun RowScope.DayCell(
    day: LocalDate,
    selected: Boolean,
    isToday: Boolean,
    hasSession: Boolean,
    hasTodo: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .weight(1f)
            .height(46.dp)
            .padding(2.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) ExamOrange else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                day.dayOfMonth.toString(),
                fontWeight = if (isToday) FontWeight.Bold else FontWeight.Normal,
                color = when {
                    selected -> ExamBg
                    isToday -> ExamOrange
                    else -> Color.White
                }
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                modifier = Modifier.height(6.dp)
            ) {
                if (hasSession) {
                    Box(Modifier.size(5.dp).clip(CircleShape).background(if (selected) ExamBg else ExamTeal))
                }
                if (hasTodo) {
                    Box(Modifier.size(5.dp).clip(CircleShape).background(if (selected) ExamBg else ExamPurple))
                }
            }
        }
    }
}

@Composable
fun CalendarTab(vm: PlannerViewModel) {
    val sessions by vm.sessions.collectAsState()
    val todos by vm.todos.collectAsState()
    val subjects by vm.subjects.collectAsState()
    val chapters by vm.chapters.collectAsState()
    val now = rememberNow()

    val today = todayDate()
    var month by remember { mutableStateOf(YearMonth.from(today)) }
    var selected by remember { mutableStateOf(today) }
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<StudySessionEntity?>(null) }
    var deletingSession by remember { mutableStateOf<StudySessionEntity?>(null) }
    var editingTodo by remember { mutableStateOf<TodoEntity?>(null) }

    val subjectMap = remember(subjects) { subjects.associateBy { it.id } }
    val chapterMap = remember(chapters) { chapters.associateBy { it.id } }
    val sessionDays = remember(sessions) { sessions.map { it.startMillis.toLocalDate() }.toSet() }
    val todoDays = remember(todos) {
        todos.filter { !it.done && it.deadlineMillis != 0L }
            .map { it.deadlineMillis.toLocalDate() }
            .toSet()
    }

    val offset = month.atDay(1).dayOfWeek.value - 1
    val total = month.lengthOfMonth()
    val rows = (offset + total + 6) / 7

    val daySessions = sessions
        .filter { it.startMillis.toLocalDate() == selected }
        .sortedBy { it.startMillis }
    val dayTodos = todos
        .filter { it.deadlineMillis != 0L && it.deadlineMillis.toLocalDate() == selected }
        .sortedBy { it.deadlineMillis }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = { month = month.minusMonths(1) }) { Text("<") }
            Text(
                month.month.getDisplayName(java.time.format.TextStyle.FULL, Locale.getDefault()) +
                    " " + month.year,
                modifier = Modifier.weight(1f),
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.SemiBold,
                fontSize = 17.sp
            )
            OutlinedButton(onClick = { month = month.plusMonths(1) }) { Text(">") }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(ExamSurface)
                .padding(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                listOf("M", "T", "W", "T", "F", "S", "S").forEach { label ->
                    Text(
                        label,
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center,
                        color = ExamTextSoft,
                        fontSize = 12.sp
                    )
                }
            }
            for (r in 0 until rows) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val dayNumber = r * 7 + c - offset + 1
                        if (dayNumber in 1..total) {
                            val date = month.atDay(dayNumber)
                            DayCell(
                                day = date,
                                selected = date == selected,
                                isToday = date == today,
                                hasSession = date in sessionDays,
                                hasTodo = date in todoDays,
                                onClick = { selected = date }
                            )
                        } else {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(ExamTeal))
                Text("  Study session", color = ExamTextSoft, fontSize = 12.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(ExamPurple))
                Text("  Task deadline", color = ExamTextSoft, fontSize = 12.sp)
            }
        }

        SectionHeader(formatDay(selected.startMillis()))

        Button(
            onClick = { adding = true },
            colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
        ) { Text("Is din session add karo") }

        if (daySessions.isEmpty() && dayTodos.isEmpty()) {
            Text("Is din koi session ya task deadline nahi hai.", color = ExamTextSoft)
        }

        daySessions.forEach { session ->
            SessionRow(
                session = session,
                subject = subjectMap[session.subjectId],
                chapter = chapterMap[session.chapterId],
                onToggle = { vm.toggleSession(session) },
                onEdit = { editing = session },
                onTomorrow = {
                    vm.saveSession(
                        session.copy(
                            startMillis = session.startMillis + DAY_MS,
                            endMillis = session.endMillis + DAY_MS
                        )
                    )
                },
                onDelete = { deletingSession = session }
            )
        }
        dayTodos.forEach { todo ->
            TodoRow(
                todo = todo,
                subject = subjectMap[todo.subjectId],
                now = now,
                onToggle = { vm.toggleTodo(todo) },
                onEdit = { editingTodo = todo },
                onDelete = null
            )
        }
        Spacer(Modifier.height(24.dp))
    }

    if (adding) {
        SessionDialog(
            initial = null,
            defaultDate = selected,
            subjects = subjects,
            chapters = chapters,
            onDismiss = { adding = false },
            onSave = {
                vm.saveSession(it)
                adding = false
            }
        )
    }
    editing?.let { session ->
        SessionDialog(
            initial = session,
            defaultDate = selected,
            subjects = subjects,
            chapters = chapters,
            onDismiss = { editing = null },
            onSave = {
                vm.saveSession(it)
                editing = null
            }
        )
    }
    editingTodo?.let { todo ->
        TodoDialog(
            initial = todo,
            defaultDate = selected,
            subjects = subjects,
            onDismiss = { editingTodo = null },
            onSave = {
                vm.saveTodo(it)
                editingTodo = null
            }
        )
    }
    deletingSession?.let { session ->
        ConfirmDeleteDialog(
            what = session.title.ifBlank { "Study session" },
            onConfirm = {
                vm.deleteSession(session)
                deletingSession = null
            },
            onDismiss = { deletingSession = null }
        )
    }
}
