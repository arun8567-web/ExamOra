package com.examora.app.ui.planner

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.data.planner.ChapterEntity
import com.examora.app.data.planner.SubjectEntity
import com.examora.app.ui.PlannerViewModel
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamTextSoft

@Composable
fun SubjectsTab(vm: PlannerViewModel) {
    val subjects by vm.subjects.collectAsState()
    val chapters by vm.chapters.collectAsState()

    var subjectDialog by remember { mutableStateOf(false) }
    var editingSubject by remember { mutableStateOf<SubjectEntity?>(null) }
    var deletingSubject by remember { mutableStateOf<SubjectEntity?>(null) }
    var addingChapterFor by remember { mutableStateOf<SubjectEntity?>(null) }
    var editingChapter by remember { mutableStateOf<ChapterEntity?>(null) }
    var deletingChapter by remember { mutableStateOf<ChapterEntity?>(null) }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, top = 12.dp, end = 20.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Button(
                onClick = { subjectDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
            ) { Text("Subject add karo") }
        }
        if (subjects.isEmpty()) {
            item {
                Text(
                    "Abhi koi subject nahi hai. Physics, Chemistry, Maths jaise subjects add karo, " +
                        "phir unke chapters. Sessions aur tasks me inhe chun sakte ho.",
                    color = ExamTextSoft
                )
            }
        }
        items(subjects) { subject ->
            val own = chapters.filter { it.subjectId == subject.id }
            val doneCount = own.count { it.done }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(ExamSurface)
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(subjectColor(subject.colorIndex))
                    )
                    Column(modifier = Modifier.weight(1f).padding(start = 10.dp)) {
                        Text(subject.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text(
                            "$doneCount / ${own.size} chapters complete",
                            color = ExamTextSoft,
                            fontSize = 12.sp
                        )
                    }
                    IconButton(onClick = { editingSubject = subject }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit subject")
                    }
                    IconButton(onClick = { deletingSubject = subject }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete subject")
                    }
                }
                own.forEach { chapter ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = chapter.done,
                            onCheckedChange = { vm.saveChapter(chapter.copy(done = !chapter.done)) },
                            colors = CheckboxDefaults.colors(checkedColor = ExamOrange)
                        )
                        Text(
                            chapter.name,
                            modifier = Modifier.weight(1f),
                            textDecoration = if (chapter.done) TextDecoration.LineThrough else null
                        )
                        IconButton(onClick = { editingChapter = chapter }) {
                            Icon(Icons.Filled.Edit, contentDescription = "Edit chapter")
                        }
                        IconButton(onClick = { deletingChapter = chapter }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete chapter")
                        }
                    }
                }
                TextButton(onClick = { addingChapterFor = subject }) {
                    Text("Chapter add karo", color = ExamOrange)
                }
            }
        }
    }

    if (subjectDialog) {
        SubjectDialog(
            initial = null,
            onDismiss = { subjectDialog = false },
            onSave = {
                vm.saveSubject(it)
                subjectDialog = false
            }
        )
    }
    editingSubject?.let { subject ->
        SubjectDialog(
            initial = subject,
            onDismiss = { editingSubject = null },
            onSave = {
                vm.saveSubject(it)
                editingSubject = null
            }
        )
    }
    deletingSubject?.let { subject ->
        ConfirmDeleteDialog(
            what = subject.name + " (uske chapters bhi)",
            onConfirm = {
                vm.deleteSubject(subject)
                deletingSubject = null
            },
            onDismiss = { deletingSubject = null }
        )
    }
    addingChapterFor?.let { subject ->
        NameDialog(
            title = subject.name + ": chapter add karo",
            label = "Chapter name",
            initial = "",
            onDismiss = { addingChapterFor = null },
            onSave = { name ->
                vm.saveChapter(ChapterEntity(subjectId = subject.id, name = name))
                addingChapterFor = null
            }
        )
    }
    editingChapter?.let { chapter ->
        NameDialog(
            title = "Chapter edit karo",
            label = "Chapter name",
            initial = chapter.name,
            onDismiss = { editingChapter = null },
            onSave = { name ->
                vm.saveChapter(chapter.copy(name = name))
                editingChapter = null
            }
        )
    }
    deletingChapter?.let { chapter ->
        ConfirmDeleteDialog(
            what = chapter.name,
            onConfirm = {
                vm.deleteChapter(chapter)
                deletingChapter = null
            },
            onDismiss = { deletingChapter = null }
        )
    }
}
