package com.examora.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.examora.app.data.ExamEntity
import com.examora.app.ui.ExamViewModel
import com.examora.app.ui.components.ExamCard
import com.examora.app.ui.components.ExamDialog
import com.examora.app.ui.components.rememberNow
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamTextSoft

@Composable
fun ExamsScreen(vm: ExamViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val exams by vm.exams.collectAsState()
    val now = rememberNow()

    // null = closed; an ExamEntity (id 0 = new/prefilled, id > 0 = edit)
    var dialogItem by remember { mutableStateOf<ExamEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<ExamEntity?>(null) }

    var notifGranted by remember {
        mutableStateOf(
            Build.VERSION.SDK_INT < 33 ||
                ContextCompat.checkSelfPermission(
                    context, Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
        )
    }
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> notifGranted = granted }

    val upcoming = exams.filter { it.timeMillis > now }
    val completed = exams.filter { it.timeMillis <= now }.sortedByDescending { it.timeMillis }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Text(
                "Exams & Events",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Text("Add")
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (!notifGranted) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(ExamSurface)
                            .padding(16.dp)
                    ) {
                        Text("Notifications band hain", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Exam se 1 din pehle aur exam ke time par reminder ke liye permission do.",
                            color = ExamTextSoft,
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = {
                            if (Build.VERSION.SDK_INT >= 33) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }) { Text("Allow notifications") }
                    }
                }
            }

            item { SectionTitle("Upcoming (${upcoming.size})") }
            if (upcoming.isEmpty()) {
                item { Text("Koi upcoming exam ya event nahi hai.", color = ExamTextSoft) }
            }
            itemsIndexed(upcoming, key = { _, e -> e.id }) { index, exam ->
                ExamCard(exam = exam, now = now) {
                    IconButton(
                        onClick = { vm.swapOrder(exam, upcoming[index - 1]) },
                        enabled = index > 0
                    ) { Icon(Icons.Filled.KeyboardArrowUp, contentDescription = "Move up") }
                    IconButton(
                        onClick = { vm.swapOrder(exam, upcoming[index + 1]) },
                        enabled = index < upcoming.lastIndex
                    ) { Icon(Icons.Filled.KeyboardArrowDown, contentDescription = "Move down") }
                    IconButton(onClick = { dialogItem = exam }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit")
                    }
                    IconButton(onClick = { deleteTarget = exam }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete")
                    }
                }
            }

            item { SectionTitle("Completed (${completed.size})") }
            if (completed.isEmpty()) {
                item { Text("Abhi koi exam complete nahi hua.", color = ExamTextSoft) }
            }
            items(completed, key = { it.id }) { exam ->
                ExamCard(exam = exam, now = now, compact = true) {
                    if (!exam.isEvent) {
                        TextButton(onClick = {
                            dialogItem = exam.copy(id = 0, attempt = exam.attempt + 1, sortOrder = 0)
                        }) { Text("Next attempt add karo", color = ExamOrange) }
                    }
                    IconButton(onClick = { deleteTarget = exam }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete")
                    }
                }
            }

            item { Spacer(Modifier.height(24.dp)) }
        }
    }

    if (showAddDialog) {
        ExamDialog(
            initial = null,
            onDismiss = { showAddDialog = false },
            onSave = {
                vm.save(it)
                showAddDialog = false
            }
        )
    }

    dialogItem?.let { item ->
        ExamDialog(
            initial = item,
            onDismiss = { dialogItem = null },
            onSave = {
                vm.save(it)
                dialogItem = null
            }
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete karna hai?") },
            text = { Text("\"${target.name}\" hata diya jayega.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.delete(target)
                    deleteTarget = null
                }) { Text("Delete", color = ExamOrange) }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) { Text("Cancel") }
            }
        )
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = ExamOrange)
}
