package com.examora.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.LinearGradient
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.examora.app.MainActivity
import com.examora.app.R
import com.examora.app.data.AppDatabase
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Draws the countdown widget for every placed instance.
 *
 * Days left are plain text. The remaining time inside the current day is a countdown
 * Chronometer, which keeps ticking live without waking the app. A WorkManager job redraws
 * the widget exactly when the day count changes, and whenever exam data changes.
 */
object ExamWidgetUpdater {
    private const val WORK_NAME = "widget_refresh"
    private const val DAY_MS = 24L * 60 * 60 * 1000

    /** Redraw soon (called when data changes or a widget is added). */
    fun refresh(context: Context) {
        val request = OneTimeWorkRequestBuilder<ExamWidgetWorker>().build()
        WorkManager.getInstance(context)
            .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }

    private fun scheduleNext(context: Context, delayMs: Long) {
        val request = OneTimeWorkRequestBuilder<ExamWidgetWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .build()
        WorkManager.getInstance(context)
            .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request)
    }


    private fun createWidgetBackground(background: Int, accent: Int, layout: Int, category: String): Bitmap {
        val width = 720
        val height = 360
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        val darkAccent = android.graphics.Color.rgb(
            (android.graphics.Color.red(accent) * 0.34f).toInt(),
            (android.graphics.Color.green(accent) * 0.34f).toInt(),
            (android.graphics.Color.blue(accent) * 0.34f).toInt()
        )
        val endColor = when (layout % 5) {
            0 -> background
            1 -> darkAccent
            2 -> blend(background, accent, 0.20f)
            3 -> blend(background, accent, 0.10f)
            else -> blend(background, android.graphics.Color.BLACK, 0.12f)
        }
        paint.shader = LinearGradient(0f, 0f, width.toFloat(), height.toFloat(), background, endColor, Shader.TileMode.CLAMP)
        canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), 54f, 54f, paint)
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.color = accent
        paint.alpha = 34

        // Theme-specific visual language: leaves/flowers, landscapes, tricolor ribbons,
        // notebook rules, study-desk lights, space stars, glass rings and HUD grids.
        when (category) {
            "Nature" -> {
                for (i in 0..6) {
                    val x = 500f + i * 34f
                    val y = 40f + (i % 3) * 28f
                    paint.alpha = 38
                    canvas.drawOval(RectF(x, y, x + 85f, y + 28f), paint)
                }
                paint.alpha = 55
                val path = android.graphics.Path().apply {
                    moveTo(380f, 360f); lineTo(500f, 180f); lineTo(590f, 275f); lineTo(660f, 205f); lineTo(720f, 290f); lineTo(720f, 360f); close()
                }
                canvas.drawPath(path, paint)
            }
            "Tricolor" -> {
                paint.alpha = 72
                canvas.drawRect(0f, 0f, 720f, 38f, paint)
                paint.color = android.graphics.Color.WHITE; paint.alpha = 65
                canvas.drawRect(0f, 38f, 720f, 76f, paint)
                paint.color = android.graphics.Color.rgb(19, 136, 8); paint.alpha = 72
                canvas.drawRect(0f, 76f, 720f, 112f, paint)
                paint.color = accent; paint.alpha = 90; paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f
                canvas.drawCircle(640f, 180f, 62f, paint); paint.style = Paint.Style.FILL
            }
            "Study" -> {
                paint.alpha = 55
                for (y in 72..330 step 42) canvas.drawLine(380f, y.toFloat(), 700f, y.toFloat(), paint)
                paint.alpha = 75
                canvas.drawCircle(650f, 60f, 45f, paint)
                paint.alpha = 80
                canvas.drawRect(520f, 255f, 700f, 274f, paint)
            }
            "Dark", "Neon" -> {
                paint.alpha = 65; paint.style = Paint.Style.STROKE; paint.strokeWidth = if (category == "Neon") 7f else 3f
                canvas.drawRoundRect(RectF(16f, 16f, 704f, 344f), 42f, 42f, paint)
                paint.strokeWidth = 2f
                for (x in 430..700 step 45) canvas.drawLine(x.toFloat(), 20f, x.toFloat(), 340f, paint)
                for (y in 30..340 step 45) canvas.drawLine(420f, y.toFloat(), 700f, y.toFloat(), paint)
                paint.style = Paint.Style.FILL
            }
            "Glassy" -> {
                paint.alpha = 55
                canvas.drawRoundRect(RectF(390f, 25f, 690f, 335f), 44f, 44f, paint)
                paint.alpha = 100; paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f
                canvas.drawRoundRect(RectF(405f, 40f, 675f, 320f), 38f, 38f, paint)
                paint.style = Paint.Style.FILL
            }
            "Anime" -> {
                paint.alpha = 48
                canvas.drawCircle(630f, 85f, 58f, paint)
                paint.alpha = 75
                for (i in 0..16) canvas.drawCircle((430 + (i * 47) % 270).toFloat(), (20 + (i * 61) % 310).toFloat(), 3f + (i % 3), paint)
            }
            "Countdown" -> {
                paint.alpha = 75; paint.style = Paint.Style.STROKE; paint.strokeWidth = 12f
                canvas.drawArc(RectF(475f, 45f, 690f, 260f), -90f, 270f, false, paint)
                paint.style = Paint.Style.FILL
                paint.alpha = 38
                canvas.drawRoundRect(RectF(490f, 275f, 690f, 315f), 18f, 18f, paint)
            }
            else -> {
                paint.alpha = 45
                for (i in 0..10) canvas.drawCircle((450 + (i * 61) % 250).toFloat(), (25 + (i * 37) % 300).toFloat(), 5f + (i % 4) * 4f, paint)
            }
        }
        // Each of the twenty presets also receives a distinct composition motif.
        paint.color = accent; paint.alpha = 45
        when (layout) {
            0 -> for (i in 0..5) canvas.drawCircle(620f, 55f + i * 42f, 8f + i * 4f, paint)
            1 -> for (i in 0..8) canvas.drawLine(420f + i * 34f, 20f, 560f + i * 16f, 340f, paint)
            2 -> canvas.drawOval(RectF(470f, 25f, 710f, 310f), paint)
            3 -> for (i in 0..5) canvas.drawRoundRect(RectF(450f + i * 35f, 55f, 470f + i * 35f, 305f), 10f, 10f, paint)
            4 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 8f; canvas.drawCircle(610f, 180f, 110f, paint); paint.style = Paint.Style.FILL }
            5 -> for (i in 0..12) canvas.drawCircle(420f + (i * 29 % 260), 35f + (i * 53 % 290), 4f, paint)
            6 -> { canvas.drawRect(430f, 245f, 700f, 270f, paint); canvas.drawRect(460f, 285f, 665f, 310f, paint) }
            7 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 4f; canvas.drawRoundRect(RectF(430f, 35f, 690f, 325f), 24f, 24f, paint); paint.style = Paint.Style.FILL }
            8 -> for (i in 0..4) canvas.drawArc(RectF(460f + i * 13f, 30f + i * 13f, 700f - i * 13f, 330f - i * 13f), 180f, 180f, false, paint)
            9 -> { canvas.drawCircle(625f, 180f, 92f, paint); paint.color = background; canvas.drawCircle(625f, 180f, 62f, paint) }
            10 -> { for (i in 0..7) canvas.drawLine(430f, 45f + i * 38f, 700f, 45f + i * 38f, paint); for (i in 0..5) canvas.drawLine(445f + i * 42f, 35f, 445f + i * 42f, 330f, paint) }
            11 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 7f; canvas.drawArc(RectF(455f, 35f, 700f, 315f), -110f, 220f, false, paint); paint.style = Paint.Style.FILL }
            12 -> for (i in 0..4) { canvas.drawOval(RectF(520f + i * 18f, 35f + i * 25f, 610f + i * 18f, 85f + i * 25f), paint) }
            13 -> { canvas.drawRect(440f, 55f, 700f, 105f, paint); canvas.drawRect(470f, 125f, 680f, 175f, paint); canvas.drawRect(500f, 195f, 660f, 245f, paint) }
            14 -> for (i in 0..9) canvas.drawCircle(430f + (i * 27 % 260), 30f + (i * 31 % 300), 5f + (i % 3) * 3f, paint)
            15 -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f; for (i in 0..3) canvas.drawRoundRect(RectF(440f + i * 12f, 30f + i * 12f, 700f - i * 12f, 330f - i * 12f), 28f, 28f, paint); paint.style = Paint.Style.FILL }
            16 -> { canvas.drawCircle(620f, 180f, 100f, paint); canvas.drawCircle(620f, 180f, 72f, android.graphics.Paint(Paint.ANTI_ALIAS_FLAG).apply { color = background }) }
            17 -> for (i in 0..6) canvas.drawLine(450f + i * 34f, 330f, 570f + i * 18f, 25f, paint)
            18 -> { canvas.drawRect(445f, 65f, 695f, 95f, paint); canvas.drawRect(445f, 125f, 645f, 155f, paint); canvas.drawRect(445f, 185f, 675f, 215f, paint) }
            else -> { paint.style = Paint.Style.STROKE; paint.strokeWidth = 12f; canvas.drawCircle(620f, 180f, 110f, paint); paint.style = Paint.Style.FILL; canvas.drawCircle(620f, 180f, 68f, paint) }
        }
        return bitmap
    }

    private fun blend(from: Int, to: Int, amount: Float): Int {
        fun channel(a: Int, b: Int) = (a + (b - a) * amount).toInt().coerceIn(0, 255)
        return android.graphics.Color.rgb(
            channel(android.graphics.Color.red(from), android.graphics.Color.red(to)),
            channel(android.graphics.Color.green(from), android.graphics.Color.green(to)),
            channel(android.graphics.Color.blue(from), android.graphics.Color.blue(to))
        )
    }

    /** Redraws all widgets, then schedules the next redraw. */
    suspend fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val ids = manager.getAppWidgetIds(ComponentName(context, ExamWidgetProvider::class.java))
        if (ids.isEmpty()) return

        val now = System.currentTimeMillis()
        val next = AppDatabase.get(context).examDao().getAll()
            .filter { it.timeMillis > now }
            .minByOrNull { it.timeMillis }

        val views = RemoteViews(context.packageName, R.layout.widget_countdown)
        val style = WidgetStyles.selected(context)
        val artworkId = context.resources.getIdentifier("widget_home_${style.id}", "drawable", context.packageName)
        val artwork = if (artworkId != 0) android.graphics.BitmapFactory.decodeResource(context.resources, artworkId) else null
        val widgetBackground = if (artwork != null) Bitmap.createScaledBitmap(artwork, 720, 360, true)
            else createWidgetBackground(style.background.toInt(), style.accent.toInt(), style.layout, style.category)
        views.setImageViewBitmap(R.id.w_background, widgetBackground)
        views.setTextColor(R.id.w_label, style.accent.toInt())
        views.setTextColor(R.id.w_days, style.accent.toInt())
        views.setTextColor(R.id.w_name, style.text.toInt())
        views.setTextColor(R.id.w_chrono, style.text.toInt())
        views.setTextColor(R.id.w_days_unit, style.muted.toInt())
        views.setTextColor(R.id.w_date, style.muted.toInt())
        views.setTextColor(R.id.w_quote, style.text.toInt())
        val quotes = listOf(
            "Small steps, big goals.", "Consistency creates results.",
            "Focus on progress, not perfection.", "Your effort today shapes tomorrow.",
            "Dream big. Study smart. Stay steady."
        )
        val quoteIndex = ((System.currentTimeMillis() / DAY_MS) % quotes.size).toInt()
        views.setTextViewText(R.id.w_quote, "")\n        views.setViewVisibility(R.id.w_quote, View.GONE)
        views.setTextViewTextSize(R.id.w_days, android.util.TypedValue.COMPLEX_UNIT_SP,
            if (style.layout % 5 == 1) 42f else if (style.layout % 5 == 3) 32f else 36f)
        var nextDelay: Long? = null

        if (next == null) {
            views.setTextViewText(R.id.w_label, "ExamOra")
            views.setTextViewText(R.id.w_name, "Koi upcoming exam nahi")
            views.setTextViewText(R.id.w_days, "--")
            views.setTextViewText(R.id.w_days_unit, "")
            views.setViewVisibility(R.id.w_chrono, View.GONE)
            views.setTextViewText(R.id.w_date, "App kholke exam add karo")
            views.setViewVisibility(R.id.w_quote, View.GONE)
        } else {
            val diff = next.timeMillis - now
            val days = diff / DAY_MS
            val remainder = diff % DAY_MS

            views.setTextViewText(R.id.w_label, if (next.isEvent) "EVENT • ${style.category.uppercase(Locale.getDefault())}" else "EXAM • ${style.category.uppercase(Locale.getDefault())}")
            views.setTextViewText(R.id.w_name, next.name)
            views.setViewVisibility(R.id.w_quote, View.GONE)
            views.setTextViewText(R.id.w_days, days.toString())
            views.setTextViewText(R.id.w_days_unit, if (days == 1L) "day left" else "days left")
            views.setViewVisibility(R.id.w_chrono, View.VISIBLE)
            views.setChronometerCountDown(R.id.w_chrono, true)
            views.setChronometer(
                R.id.w_chrono,
                SystemClock.elapsedRealtime() + remainder,
                null,
                true
            )
            views.setTextViewText(
                R.id.w_date,
                SimpleDateFormat("EEE, d MMM yyyy  hh:mm a", Locale.getDefault())
                    .format(next.timeMillis)
            )
            nextDelay = maxOf(remainder + 5_000L, 30_000L)
        }

        val openApp = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        views.setOnClickPendingIntent(R.id.w_root, openApp)

        manager.updateAppWidget(ids, views)
        if (nextDelay != null) scheduleNext(context, nextDelay)
    }
}

class ExamWidgetWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        ExamWidgetUpdater.updateAll(applicationContext)
        return Result.success()
    }
}
