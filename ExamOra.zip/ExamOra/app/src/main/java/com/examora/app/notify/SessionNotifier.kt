package com.examora.app.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.examora.app.data.planner.StudySessionEntity
import java.util.concurrent.TimeUnit

/**
 * One reminder per study session: 10 minutes before the start. If the session starts in
 * less than 10 minutes, the reminder fires at the start time instead. Completed or past
 * sessions get no reminder. Delivery can be a few minutes late under battery saver / Doze.
 */
object SessionNotifier {
    const val CHANNEL_ID = "study_sessions"
    private const val LEAD_MS = 10L * 60 * 1000

    fun createChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Study sessions",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Study session reminders" }
        nm.createNotificationChannel(channel)
    }

    private fun workName(id: Long) = "session_$id"

    /** [label] is the text shown in the notification, e.g. "Physics - Kinematics". */
    fun schedule(context: Context, session: StudySessionEntity, label: String) {
        val wm = WorkManager.getInstance(context)
        val now = System.currentTimeMillis()
        var at = session.startMillis - LEAD_MS
        var lead = true
        if (at <= now) {
            at = session.startMillis
            lead = false
        }
        if (session.done || at <= now) {
            wm.cancelUniqueWork(workName(session.id))
            return
        }
        val request = OneTimeWorkRequestBuilder<SessionNotificationWorker>()
            .setInitialDelay(at - now, TimeUnit.MILLISECONDS)
            .setInputData(
                workDataOf(
                    "id" to session.id,
                    "label" to label,
                    "lead" to lead
                )
            )
            .build()
        wm.enqueueUniqueWork(workName(session.id), ExistingWorkPolicy.REPLACE, request)
    }

    fun cancel(context: Context, id: Long) {
        WorkManager.getInstance(context).cancelUniqueWork(workName(id))
    }
}
