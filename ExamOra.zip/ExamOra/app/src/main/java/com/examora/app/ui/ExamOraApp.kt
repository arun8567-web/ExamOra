package com.examora.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.examora.app.ui.screens.ComingSoonScreen
import com.examora.app.ui.screens.ExamsScreen
import com.examora.app.ui.screens.HomeScreen
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamTextSoft

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("planner", "Planner", Icons.Filled.DateRange),
    Tab("widgets", "Widgets", Icons.Filled.Widgets),
    Tab("progress", "Progress", Icons.Filled.BarChart),
    Tab("settings", "Settings", Icons.Filled.Settings)
)

@Composable
fun ExamOraApp() {
    val nav = rememberNavController()
    val examVm: ExamViewModel = viewModel()
    val backStack by nav.currentBackStackEntryAsState()
    val current = backStack?.destination?.route

    val goTo: (String) -> Unit = { route ->
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        containerColor = ExamBg,
        bottomBar = {
            NavigationBar(
                containerColor = ExamSurface,
                tonalElevation = 0.dp
            ) {
                tabs.forEach { tab ->
                    val selected = current == tab.route ||
                        (tab.route == "home" && current == "exams")
                    NavigationBarItem(
                        selected = selected,
                        onClick = { goTo(tab.route) },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = ExamBg,
                            selectedTextColor = ExamOrange,
                            indicatorColor = ExamOrange,
                            unselectedIconColor = ExamTextSoft,
                            unselectedTextColor = ExamTextSoft
                        )
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = "home",
            modifier = Modifier.padding(padding)
        ) {
            composable("home") {
                HomeScreen(
                    vm = examVm,
                    onOpenTab = goTo,
                    onOpenExams = {
                        nav.navigate("exams") { launchSingleTop = true }
                    }
                )
            }
            composable("exams") {
                ExamsScreen(vm = examVm, onBack = { nav.popBackStack() })
            }
            composable("planner") {
                ComingSoonScreen("Planner", "Study planner, calendar aur To-Do manager Phase 3 me aayega.")
            }
            composable("widgets") {
                ComingSoonScreen("Widgets", "Widget gallery (160 designs) Phase 6-7 me aayegi.")
            }
            composable("progress") {
                ComingSoonScreen("Progress", "Study analytics Phase 5 me aayega, focus timer ke data ke baad.")
            }
            composable("settings") {
                ComingSoonScreen("Settings", "Theme, accent color aur notification settings baad ke phases me aayengi.")
            }
        }
    }
}
