# ExamOra (Phase 2)

Plan Smart. Study Better. Achieve More.

## Abhi kya kaam karta hai
- Dark premium theme, launcher icon, splash screen, 5-tab bottom navigation
- Home: greeting, date, next exam ka live countdown, aur 3 tak aur upcoming exam cards, motivation quote
- Exams & Events screen (Home -> "Sab exams manage karo"):
  - Multiple exams / custom events add, edit, delete (delete se pehle confirm)
  - Naam, date, time, exam attempt number (Attempt 2, 3...)
  - 6 countdown themes (Classic, Orange, Purple, Blue, Teal, Green)
  - Upar/neeche arrow se reorder
  - Upcoming aur Completed sections, completed exam par "Next attempt add karo"
  - Data Room database me save hota hai (Phase 1 ka purana exam apne aap migrate ho jata hai)
- Notifications: exam se 1 din pehle aur exam ke time par (WorkManager). Android 13+ par permission maangta hai.

## Limits (honest)
- Notification kabhi kabhi kuch minute late aa sakta hai (battery saver / Doze), exact second par guarantee nahi.
- Notification ka on/off settings screen abhi nahi hai (Settings tab baad me).
- Planner, Widgets, Progress, Settings tabs abhi "Abhi built nahi hai" dikhate hain.
- Ye code abhi kisi build ya device par test nahi hua.

## Phone se APK banane ke steps
1. GitHub repo me purani `ExamOra.zip` ki jagah nayi `ExamOra.zip` upload karo (same naam = replace). Extract MAT karo.
2. `.github/workflows/build.yml` pehle se hai, usko badalne ki zarurat nahi.
3. Commit ke baad Actions tab me build chalega, phir Artifacts se APK download karo.
4. Purane app ke upar hi install kar do, data bacha rahega.
