package com.examora.app.ui.components

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.examora.app.data.ExamEntity
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamTextSoft
import java.util.Calendar

private fun defaultExamTime(): Long =
    Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, 30)
        set(Calendar.HOUR_OF_DAY, 9)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }.timeInMillis

/**
 * Add / edit dialog. [initial] == null means a brand new item.
 * An [initial] with id == 0 is a prefilled new item (used for "next attempt").
 */
@Composable
fun ExamDialog(
    initial: ExamEntity?,
    onDismiss: () -> Unit,
    onSave: (ExamEntity) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var isEvent by remember { mutableStateOf(initial?.isEvent ?: false) }
    var attempt by remember { mutableIntStateOf(initial?.attempt ?: 1) }
    var themeIndex by remember { mutableIntStateOf(initial?.themeIndex ?: 0) }
    var millis by remember {
        mutableLongStateOf(
            if (initial != null && initial.timeMillis > System.currentTimeMillis()) {
                initial.timeMillis
            } else {
                defaultExamTime()
            }
        )
    }

    val isNew = initial == null || initial.id == 0L
    val shown = remember(millis) { formatExamDate(millis) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Exam / Event add karo" else "Edit karo") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Naam (e.g. JEE Main 2027)") },
                    singleLine = true
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = !isEvent,
                        onClick = { isEvent = false },
                        label = { Text("Exam") }
                    )
                    FilterChip(
                        selected = isEvent,
                        onClick = { isEvent = true },
                        label = { Text("Custom event") }
                    )
                }

                if (!isEvent) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Attempt: $attempt", color = ExamTextSoft)
                        OutlinedButton(
                            onClick = { if (attempt > 1) attempt-- },
                            enabled = attempt > 1
                        ) { Text("-") }
                        OutlinedButton(onClick = { if (attempt < 9) attempt++ }) { Text("+") }
                    }
                }

                Text("Date & time: $shown", color = ExamTextSoft)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = millis }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val u = Calendar.getInstance().apply {
                                    timeInMillis = millis
                                    set(y, m, d)
                                }
                                millis = u.timeInMillis
                            },
                            c.get(Calendar.YEAR),
                            c.get(Calendar.MONTH),
                            c.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    }) { Text("Date") }
                    OutlinedButton(onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = millis }
                        TimePickerDialog(
                            context,
                            { _, h, min ->
                                val u = Calendar.getInstance().apply {
                                    timeInMillis = millis
                                    set(Calendar.HOUR_OF_DAY, h)
                                    set(Calendar.MINUTE, min)
                                    set(Calendar.SECOND, 0)
                                    set(Calendar.MILLISECOND, 0)
                                }
                                millis = u.timeInMillis
                            },
                            c.get(Calendar.HOUR_OF_DAY),
                            c.get(Calendar.MINUTE),
                            false
                        ).show()
                    }) { Text("Time") }
                }

                Text("Countdown theme: ${countdownThemes[themeIndex].name}", color = ExamTextSoft)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    countdownThemes.forEachIndexed { index, theme ->
                        ThemeDot(
                            color = theme.colors[0],
                            selected = index == themeIndex,
                            onClick = { themeIndex = index }
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = name.isNotBlank(),
                onClick = {
                    onSave(
                        ExamEntity(
                            id = initial?.id ?: 0L,
                            name = name.trim(),
                            timeMillis = millis,
                            isEvent = isEvent,
                            attempt = if (isEvent) 1 else attempt,
                            themeIndex = themeIndex,
                            sortOrder = initial?.sortOrder ?: 0L
                        )
                    )
                }
            ) { Text("Save", color = ExamOrange) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ThemeDot(color: Color, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(30.dp)
            .clip(CircleShape)
            .background(color)
            .then(
                if (selected) Modifier.border(3.dp, Color.White, CircleShape) else Modifier
            )
            .clickable(onClick = onClick)
    )
}
