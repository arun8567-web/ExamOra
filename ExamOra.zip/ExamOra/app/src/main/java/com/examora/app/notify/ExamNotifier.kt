package com.examora.app.notify

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.examora.app.data.ExamEntity
import java.util.concurrent.TimeUnit

/**
 * Schedules two notifications per exam/event with WorkManager:
 * one day before and one at the exact time. WorkManager survives app restarts and
 * reboots, but Android may deliver the notification a few minutes late (battery saver / Doze).
 */
object ExamNotifier {
    const val CHANNEL_ID = "exam_countdown"
    const val KIND_DAY_BEFORE = "day_before"
    const val KIND_NOW = "now"
    private const val DAY_MS = 24L * 60 * 60 * 1000

    fun createChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Exam countdowns",
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply { description = "Exam aur event reminders" }
        nm.createNotificationChannel(channel)
    }

    private fun workName(id: Long, kind: String) = "exam_${id}_$kind"

    fun schedule(context: Context, exam: ExamEntity) {
        val wm = WorkManager.getInstance(context)
        val now = System.currentTimeMillis()
        val targets = listOf(
            KIND_DAY_BEFORE to exam.timeMillis - DAY_MS,
            KIND_NOW to exam.timeMillis
        )
        for ((kind, at) in targets) {
            val name = workName(exam.id, kind)
            if (at > now) {
                val data = workDataOf(
                    "id" to exam.id,
                    "name" to exam.name,
                    "kind" to kind,
                    "event" to exam.isEvent
                )
                val request = OneTimeWorkRequestBuilder<ExamNotificationWorker>()
                    .setInitialDelay(at - now, TimeUnit.MILLISECONDS)
                    .setInputData(data)
                    .build()
                wm.enqueueUniqueWork(name, ExistingWorkPolicy.REPLACE, request)
            } else {
                wm.cancelUniqueWork(name)
            }
        }
    }

    fun cancel(context: Context, id: Long) {
        val wm = WorkManager.getInstance(context)
        wm.cancelUniqueWork(workName(id, KIND_DAY_BEFORE))
        wm.cancelUniqueWork(workName(id, KIND_NOW))
    }

    fun rescheduleAll(context: Context, exams: List<ExamEntity>) {
        exams.forEach { schedule(context, it) }
    }
}
