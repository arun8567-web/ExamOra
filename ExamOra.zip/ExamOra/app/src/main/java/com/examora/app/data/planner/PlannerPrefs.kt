package com.examora.app.data.planner

import android.content.Context

/** Small settings for the planner (daily study goal in minutes). */
class PlannerPrefs(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("examora_planner", Context.MODE_PRIVATE)

    fun goalMinutes(): Int = prefs.getInt(KEY_GOAL, 240)

    fun setGoalMinutes(minutes: Int) {
        prefs.edit().putInt(KEY_GOAL, minutes).apply()
    }

    private companion object {
        const val KEY_GOAL = "daily_goal_minutes"
    }
}
