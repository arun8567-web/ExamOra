package com.examora.app.ui.screens

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Widgets
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange
import com.examora.app.ui.theme.ExamSurface
import com.examora.app.ui.theme.ExamTextSoft
import com.examora.app.widget.ExamWidgetProvider
import com.examora.app.widget.ExamWidgetUpdater
import com.examora.app.widget.WidgetStyle
import com.examora.app.widget.WidgetStyles

@Composable
fun WidgetsScreen() {
    val context = LocalContext.current
    var category by remember { mutableStateOf("All") }
    var query by remember { mutableStateOf("") }
    var selectedId by remember { mutableStateOf(WidgetStyles.selected(context).id) }
    var favorites by remember { mutableStateOf(WidgetStyles.favorites(context)) }
    val selectedStyle = WidgetStyles.byId(selectedId)
    val categories = listOf("All", "Favorites") + WidgetStyles.categories
    val visibleStyles = remember(category, query, favorites) {
        WidgetStyles.all.filter { style ->
            val categoryMatch = when (category) {
                "All" -> true
                "Favorites" -> favorites.contains(style.id)
                else -> style.category == category
            }
            categoryMatch && (query.isBlank() || style.name.contains(query, true) || style.category.contains(query, true))
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(ExamBg).padding(horizontal = 16.dp)) {
        Text("Widget Gallery", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Color.White,
            modifier = Modifier.padding(top = 18.dp, bottom = 4.dp))
        Text("180 designs • 9 categories • Live countdown", color = ExamTextSoft, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))

        WidgetPreview(selectedStyle, Modifier.fillMaxWidth().height(150.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
            Column(Modifier.weight(1f)) {
                Text(selectedStyle.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("${selectedStyle.category} • ${selectedStyle.id + 1} / 180", color = ExamTextSoft, fontSize = 12.sp)
            }
            IconButton(onClick = {
                WidgetStyles.toggleFavorite(context, selectedId)
                favorites = WidgetStyles.favorites(context)
            }) {
                Icon(if (favorites.contains(selectedId)) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorite", tint = ExamOrange)
            }
            Button(onClick = {
                WidgetStyles.select(context, selectedId)
                ExamWidgetUpdater.refresh(context)
                Toast.makeText(context, "${selectedStyle.name} applied to home-screen widget", Toast.LENGTH_SHORT).show()
            }, colors = ButtonDefaults.buttonColors(containerColor = ExamOrange, contentColor = ExamBg)) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.size(5.dp))
                Text("Apply")
            }
        }

        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Search designs or categories", color = ExamTextSoft) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = ExamTextSoft) },
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                focusedBorderColor = ExamOrange, unfocusedBorderColor = ExamSurface,
                cursorColor = ExamOrange
            )
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            categories.forEach { item ->
                FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) })
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("${visibleStyles.size} designs", color = ExamOrange, fontWeight = FontWeight.Bold, fontSize = 14.sp)
        Spacer(Modifier.height(8.dp))
        if (visibleStyles.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No designs found. Search another name.", color = ExamTextSoft)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2), modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(visibleStyles, key = { it.id }) { style ->
                    StyleTile(style, selectedId == style.id, favorites.contains(style.id)) {
                        selectedId = style.id
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            val manager = AppWidgetManager.getInstance(context)
            if (manager.isRequestPinAppWidgetSupported) {
                manager.requestPinAppWidget(ComponentName(context, ExamWidgetProvider::class.java), null, null)
            } else {
                Toast.makeText(context, "Home screen long-press > Widgets > ExamOra", Toast.LENGTH_LONG).show()
            }
        }, modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = ExamSurface, contentColor = Color.White)) {
            Icon(Icons.Filled.Home, contentDescription = null)
            Spacer(Modifier.size(8.dp))
            Text("Home screen par widget lagao")
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun StyleTile(style: WidgetStyle, selected: Boolean, favorite: Boolean, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
        .then(if (selected) Modifier.border(2.dp, ExamOrange, RoundedCornerShape(16.dp)) else Modifier),
        shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = ExamSurface)) {
        Column(Modifier.padding(8.dp)) {
            Box {
                WidgetPreview(style, Modifier.fillMaxWidth().aspectRatio(1.72f))
                if (favorite) Icon(Icons.Filled.Favorite, contentDescription = "Favorite", tint = ExamOrange,
                    modifier = Modifier.align(Alignment.TopEnd).padding(7.dp).size(16.dp))
            }
            Spacer(Modifier.height(7.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(style.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (selected) Icon(Icons.Filled.CheckCircle, contentDescription = "Selected", tint = ExamOrange, modifier = Modifier.size(17.dp))
            }
        }
    }
}

@Composable
private fun WidgetPreview(style: WidgetStyle, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val imageId = remember(style.id) {
        context.resources.getIdentifier("widget_preview_${style.id}", "drawable", context.packageName)
    }
    val shape = RoundedCornerShape(18.dp)
    val darkText = style.id != 5 && style.id != 9
    val mainText = if (darkText) Color(0xFF231D1F) else Color.White
    val mutedText = if (darkText) Color(0xFF514647) else Color(0xFFECEBF5)
    Box(modifier.clip(shape)) {
        if (imageId != 0) {
            Image(
                painter = painterResource(imageId),
                contentDescription = "${style.name} widget design preview",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(Modifier.fillMaxSize().background(style.backgroundColor))
        }
        Row(
            Modifier.fillMaxSize().padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(0.92f), verticalArrangement = Arrangement.Center) {
                Text("Days Left", color = style.accentColor, fontSize = 8.sp)
                Text("77", color = style.accentColor, fontSize = 30.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("JEE Mains 2027", color = mainText, fontSize = 8.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                Text("20 Jan 2027", color = mutedText, fontSize = 7.sp, maxLines = 1)
            }
            Box(Modifier.width(1.dp).fillMaxHeight(0.78f).background(mainText.copy(alpha = 0.38f)))
            Column(Modifier.weight(1.08f).padding(start = 8.dp), verticalArrangement = Arrangement.Center) {
                Text("Quote of the Day", color = mainText, fontSize = 8.sp, maxLines = 1)
                Text("“Believe in your dreams, make them your guiding light.”", color = mainText,
                    fontSize = 9.sp, lineHeight = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Serif,
                    maxLines = 3, overflow = TextOverflow.Ellipsis)
                Text("— Anonymous", color = mutedText, fontSize = 7.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Serif)
            }
        }
    }
}
