package com.examora.app.ui.planner

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.examora.app.ui.PlannerViewModel
import com.examora.app.ui.theme.ExamBg
import com.examora.app.ui.theme.ExamOrange

@Composable
fun PlannerScreen(vm: PlannerViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("Sessions", "Calendar", "To-Do", "Subjects")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
    ) {
        Text(
            "Planner",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(start = 20.dp, top = 12.dp, end = 20.dp, bottom = 8.dp)
        )
        TabRow(
            selectedTabIndex = tab,
            containerColor = ExamBg,
            contentColor = ExamOrange
        ) {
            titles.forEachIndexed { index, title ->
                Tab(
                    selected = tab == index,
                    onClick = { tab = index },
                    text = { Text(title, fontSize = 13.sp, maxLines = 1) }
                )
            }
        }
        when (tab) {
            0 -> SessionsTab(vm)
            1 -> CalendarTab(vm)
            2 -> TodoTab(vm)
            else -> SubjectsTab(vm)
        }
    }
}
