package com.examora.app.data.planner

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/** Separate database file so the Phase 2 exam database never needs a migration. */
@Database(
    entities = [
        SubjectEntity::class,
        ChapterEntity::class,
        StudySessionEntity::class,
        TodoEntity::class,
        FocusSessionEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class PlannerDatabase : RoomDatabase() {
    abstract fun plannerDao(): PlannerDao

    companion object {
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                database.execSQL(
                    """CREATE TABLE IF NOT EXISTS focus_sessions (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        startedAtMillis INTEGER NOT NULL,
                        durationMinutes INTEGER NOT NULL,
                        actualSeconds INTEGER NOT NULL,
                        subjectId INTEGER NOT NULL,
                        mode TEXT NOT NULL,
                        completed INTEGER NOT NULL
                    )"""
                )
            }
        }

        @Volatile
        private var instance: PlannerDatabase? = null

        fun get(context: Context): PlannerDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    PlannerDatabase::class.java,
                    "planner.db"
                ).addMigrations(MIGRATION_1_2).build().also { instance = it }
            }
    }
}
